﻿label epilogue:

    window hide

    scene epilogue1
    with Fade(0.5, 2, 0)

    story "And so, Xoai, just Xoai, walked home alone, alone through the meandering streets of Saigon…"

    story "The vision of Bino faded away gently, following Xoai for some last steps…"

    scene epilogue2

    story "Back at Ba Chieu, Xoai reported back to his pack on the rise of dog poisons around the surrounding areas."

    story "Xoai taught them his 5 rules for spotting dog baits:"

    scene epilogue3

    story "\"1: Do not trust rubber bands!\""

    scene epilogue4

    story "\"2: Beware of manufactured pellets!\""

    scene epilogue5

    story "\"3: Run from sweet smelling liquids!\""

    scene epilogue6

    story "\"4: Inspect meat carefully!\""

    scene epilogue7

    story "\"And last but not least…\""

    scene epilogue8

    story "\"5: No more scavenging!\""

    scene epilogue9

    story "Shocked, the pack dogs questioned Xoai. \"How else will we get our food?\", one puppy asked."

    scene epilogue10

    story "\"I'm not sure yet, but what I know for certain is that being on high alert 24/7 will take a toll on us all.\""

    scene epilogue11

    story "\"We need security. Certainty. Someone to go to for food.\""

    scene epilogue12

    story "\"I know we are strays, and that we want to do things on our own, but it is not worth it when we have to live in fear.\""

    scene epilogue13

    story "\"We need to put one last faith in humans.\""

    scene epilogue14

    story "And so, the day after, Xoai walked around Ba Chieu, going from person to person until…"

    scene epilogue15

    story "He met a kind, old man, who offered to take in and feed the dogs each day out of his own pocket."

    scene epilogue16

    story "\"Thank you so much! We are eternally grateful for your kindness!\", Xoai exclaimed."

    story "And even though the language of barks and woofs could not be translated fully for the comprehension of humans…"

    scene epilogue17

    story "The kind man smiled, knowing in his heart that Xoai and his group were expressing gratitude."

    scene epilogue18

    story "In his new home, no longer a cardboard box facing the cold wind..."
    
    story "Xoai slept soundly for the first time in months, his stomach finally full…"

    scene epilogue19

    story "He dreamt of a dog paradise, endless rice fields and sunshine to bask in…"

    scene epilogue20

    story "In it, he could listen to the sounds of chirping birds…"

    scene epilogue21

    story "...of swaying leaves…"

    scene epilogue22

    story "...and of the pitter patter of another dog's paws, running through the grass."


    story "{i}Fin{/i}"

    jump creditsroll

    return
