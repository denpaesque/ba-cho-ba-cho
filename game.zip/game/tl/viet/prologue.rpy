﻿# TODO: Translation updated at 2026-10-28 11:10

# game/prologue.rpy:12
translate viet start_0d58ef62:

    # story "201X\nSAIGON, BA CHIEU MARKET"
    story "201X\nSài Gòn, chợ Bà Chiểu"

# game/prologue.rpy:14
translate viet start_b639d4f0:

    # story "Ever since Bino left us, the stray dogs around Ba Chieu have been scared of searching for food..."
    story "Kể từ ngày Bino rời xa tụi mình, nhóm chó hoang quanh khu chợ Bà Chiểu lúc nào cũng sợ hãi không dám đi kiếm ăn…"

# game/prologue.rpy:18
translate viet start_2d41898f:

    # story "It was rumoured that one day... he went out scouring the streets for leftovers..."
    story "Người ta đồn rằng vào một ngày nọ... cậu ấy lang thang khắp phố tìm đồ ăn thừa…"

# game/prologue.rpy:22
translate viet start_1d3e9e24:

    # story "And before we knew it..."
    story "Rồi chuyện xảy ra nhanh đến mức không ai kịp nhận ra…"

# game/prologue.rpy:26
translate viet start_dc214204:

    # story "..."
    story "..."

# game/prologue.rpy:28
translate viet start_de933df7:

    # story "No one knows what happened to him, and no one has dared to scavenge for long since..."
    story "Chẳng ai biết chính xác chuyện gì đã xảy ra với Bino, nhưng kể từ đó đến nay, cũng chẳng đứa nào dám đi sục sạo kiếm ăn lâu như trước nữa…"

# game/prologue.rpy:32
translate viet start_dc214204_1:

    # story "..."
    story "..."

# game/prologue.rpy:36
translate viet start_62985105:

    # story "*stomach growl*"
    story "*tiếng bụng réo cồn cào*"

# game/prologue.rpy:40
translate viet start_fc5773ee:

    # story "\"I'm so hungry...\""
    story "\"Đói quá đi...\""

# game/prologue.rpy:44
translate viet start_54de414a:

    # story "\"...\""
    story "\"...\""

# game/prologue.rpy:48
translate viet start_335425b9:

    # story "\"But this has to change now!!\""
    story "\"Nhưng chuyện này phải thay đổi ngay từ bây giờ!!\""

# game/prologue.rpy:52
translate viet start_3baa1487:

    # story "\"This isn't what Bino would have wanted..\""
    story "\"Nếu còn ở đây thì chắc chắn Bino không muốn thấy mình ở cảnh này..\""

# game/prologue.rpy:56
translate viet start_e3bc4491:

    # story "\"And besides, we're gonna get really tired of eating small meals every day...\""
    story "\"Tụi mình cũng sẽ ngán cảnh ngày nào cũng phải ăn cầm chừng thôi…\""

# game/prologue.rpy:60
translate viet start_0b3133f9:

    # story "\"I'm the chef of this street, for god's sake! I have to be brave and bring home food for everyone!!\""
    story "\"Trời đất ơi, mình là đầu bếp của cái xóm này cơ mà! Mình phải dũng cảm lên và tha đồ ăn về cho mọi người chứ!!\""

# game/prologue.rpy:64
translate viet start_4960adc7:

    # story "*deep breath*"
    story "*hít một hơi thật sâu*"

# game/prologue.rpy:68
translate viet start_3078d0d6:

    # story "\"Let's do this!!\""
    story "\"Bắt đầu thôi nào!!\""

