﻿# TODO: Translation updated at 2026-10-28 12:02

translate viet strings:

    # game/characters.rpy:4
    old "Xoai"
    new "Xoài"

