﻿# TODO: Translation updated at 2026-10-28 11:10

# game/street3.rpy:70
translate viet ba7_3c6a4292:

    # xoai "A weird-looking puddle… and it smells sweet?"
    xoai "Vũng nước này nhìn kỳ quá…mà lại có mùi ngọt ngọt nữa chứ?"

# game/street3.rpy:74
translate viet ba7_18fcff51:

    # xoai "This isn't water… it's… weird looking, really."
    xoai "Đây không phải nước thường đâu… nó nhìn dị thật luôn đó."

# game/street3.rpy:78
translate viet ba7_b13d0287:

    # bino "Stay back, that's straight up nuclear stuff."
    bino "Lùi lại nha, cái này chẳng khác gì rác thải hạt nhân đâu."

# game/street3.rpy:82
translate viet ba7_0d10d128:

    # bino "Or, well, more specifically, motorbike antifreeze."
    bino "Nói đúng hơn là nước mát tản nhiệt cho xe."

# game/street3.rpy:86
translate viet ba7_e8a1afb1:

    # xoai "Weird. Why is it here?"
    xoai "Kỳ vậy. Tại sao lại có cái đó ở đây vậy, anh?"

# game/street3.rpy:90
translate viet ba7_e7852b09:

    # bino "Usually, those repair shops that you see around have a dedicated tank of these to pour into bike engines and stuff."
    bino "Thường thì mấy tiệm sửa xe quanh đây có sẵn một bình để đổ vào động cơ xe máy."

# game/street3.rpy:94
translate viet ba7_16576c59:

    # bino "But I guess someone's been a bit lazy and dumped it out onto the street instead…"
    bino "Nhưng chắc có ai đó làm biếng nên đổ hết lên đường kiều này."

# game/street3.rpy:98
translate viet ba7_fd7595c7:

    # xoai "That's annoying…"
    xoai "Bực mình thật…"

# game/street3.rpy:102
translate viet ba7_6213adda:

    # bino "Yeah. Avoid it at all costs."
    bino "Ừ. Tránh xa mấy cái vũng kiểu này nha."

# game/street3.rpy:122
translate viet ba8_b2cca784:

    # xoai "Hah! I know this trick!"
    xoai "Ha! Em nhận ra rồi!"

# game/street3.rpy:126
translate viet ba8_cca7c826:

    # xoai "Meat with weird pellets in them! You can't fool me twice!"
    xoai "Thịt nhồi mấy cái viên kỳ kỳ này. Đừng mơ lừa được tôi hai lần nha!"

# game/street3.rpy:130
translate viet ba8_5b05831f:

    # bino "Nice job spotting that one, Xoài!"
    bino "Hay lắm, Xoài!"

# game/street3.rpy:134
translate viet ba8_282c56ea:

    # bino "Soon, you won't even need my guidance."
    bino "Sau này chắc không cần anh chỉ nữa đâu."

# game/street3.rpy:138
translate viet ba8_a8c2079a:

    # xoai "Hell yeah, I've made something of myself!"
    xoai "Em ngầu lên nhiều rồi!"

# game/street3.rpy:142
translate viet ba8_70d0581d:

    # xoai "But uh, it's nice having you around to watch too, you know. I don't always have to be learning something from you…"
    xoai "Nhưng có anh giúp em quan sát xung quanh cũng vui mà. Em đâu cần phải học hoài."

# game/street3.rpy:146
translate viet ba8_5b5e4260:

    # bino "..."
    bino "..."

# game/street3.rpy:150
translate viet ba8_1b692a29:

    # bino "...maybe."
    bino "...có lẽ vậy."

# game/street3.rpy:172
translate viet ba9_7c04b371:

    # xoai "This is…"
    xoai "Đây là…"

# game/street3.rpy:176
translate viet ba9_cfcfff1c:

    # xoai "Meat? With rubber bands around it?"
    xoai "Thịt? Mà sao lại buộc dây thun quanh nữa?"

# game/street3.rpy:180
translate viet ba9_8bd64f0b:

    # xoai "I don't see any weird pellets, but…"
    xoai "Em không thấy có gì lạ bên trong, nhưng…"

# game/street3.rpy:182
translate viet ba9_1e6a6c0f:

    # xoai "If the others were anything to go off of, then…"
    xoai "Nếu mấy loại bả trước chúng giấu kỹ như vậy thì chắc…"

# game/street3.rpy:186
translate viet ba9_dae3f69d:

    # xoai "Rubber bands…"
    xoai "Dây thun…"

# game/street3.rpy:190
translate viet ba9_2ba1ddeb:

    # bino "...are a no-go."
    bino "...là kiêng."

# game/street3.rpy:194
translate viet ba9_7cf60676:

    # xoai "Yeah! Something like that!"
    xoai "Đúng rồi!"

# game/street3.rpy:198
translate viet ba9_48e080c6:

    # bino "I mean, think about it? Who the hell likes eating rubber bands?!"
    bino "Mà nghĩ lại đi, ai mà lại đi ăn dây thun?"

# game/street3.rpy:202
translate viet ba9_a841e56a:

    # xoai "Yeah. Gross."
    xoai "Ứm. Gớm."

# game/street3.rpy:222
translate viet street3clear_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street3.rpy:226
translate viet street3clear_ba14e423:

    # xoai "We didn't find much after all…"
    xoai "Rốt cuộc thì cũng chẳng kiếm được bao nhiêu…"

# game/street3.rpy:230
translate viet street3clear_53a99860:

    # bino "Don't sweat it, Xoai. Let's just head back now."
    bino "Đừng lo quá nha, Xoài. Mình đi về thôi."

# game/street3.rpy:234
translate viet street3clear_5e575e68:

    # xoai "I was foolish to think it would be fun to go further out…"
    xoai "Em đúng là ngốc khi nghĩ đi ra tận ngoài này là ý hay…"

# game/street3.rpy:238
translate viet street3clear_261f182b:

    # xoai "And find treasure or something…"
    xoai "Kiểu sẽ gặp kho báu hay gì chứ…"

# game/street3.rpy:242
translate viet street3clear_9b8e98f6:

    # xoai "Like a big stash of meat for all of us!!!"
    xoai "Như một đống thịt cho cả đàn!!!"

# game/street3.rpy:246
translate viet street3clear_70a15d60:

    # xoai "But no… it just had to be dog poison, all of it…"
    xoai "Nhưng không, gần như cái gì cũng là bả thôi…"

# game/street3.rpy:250
translate viet street3clear_5b5e4260:

    # bino "..."
    bino "..."

# game/street3.rpy:252
translate viet street3clear_a766de5e:

    # bino "Don't you think you got something out of this, though?"
    bino "Em không nghĩ mình đã học được gì từ trải nghiệm này à?"

# game/street3.rpy:256
translate viet street3clear_8dfb9943:

    # xoai "...like what?"
    xoai "...như gì anh Bino?"

# game/street3.rpy:260
translate viet street3clear_6245b66b:

    # xoai "All I've learnt is that this world is… cruel sometimes…"
    xoai "Em chỉ học được rằng thế giới này…đôi khi thật tàn nhẫn…"

# game/street3.rpy:264
translate viet street3clear_d03108e7:

    # xoai "*sniff*"
    xoai "*thút thít*"

# game/street3.rpy:268
translate viet street3clear_3fb8ffd3:

    # bino "...now now, I know it's hard…"
    bino "...thôi nào, anh hiểu mà…"

# game/street3.rpy:270
translate viet street3clear_d5b26a60:

    # bino "...but you've learnt how to spot these poisons, you know? You got something out of it."
    bino "…nhưng em đã học được cách nhận biết các loại bả, đúng không? Đó cũng là thứ hay mà."

# game/street3.rpy:274
translate viet street3clear_00aaaf40:

    # bino "Think about how many lives you could save with this knowledge, Xoai. The whole pack is super safe now, thanks to your wisdom!"
    bino "Thử nghĩ xem em có thể cứu sống được bao nhiêu mạng chó với kiến thức này, Xoài. Cả đàn giờ an toàn hơn nhiều rồi, nhờ sự khôn ngoan của em đấy!"

# game/street3.rpy:278
translate viet street3clear_d9d8fb33:

    # xoai "...yeah, I guess."
    xoai "...anh nói cũng đúng."

# game/street3.rpy:282
translate viet street3clear_780bc4c1:

    # xoai "I wish it didn't have to come at the cost of you though…"
    xoai "Em chỉ ước gì cái giá phải trả không phải là mạng sống của anh…"

# game/street3.rpy:286
translate viet street3clear_6e73be04:

    # bino "...I understand."
    bino "...Anh hiểu."

# game/street3.rpy:290
translate viet street3clear_0b3d4ba3_1:

    # xoai "..."
    xoai "..."

# game/street3.rpy:294
translate viet street3clear_43514f09:

    # xoai "You're not actually here, are you Bino?"
    xoai "Anh đâu có thực sự đang ở đây với em đâu, đúng không, anh Bino?"

# game/street3.rpy:298
translate viet street3clear_47bf8be3:

    # xoai "I'm just like, making stuff up."
    xoai "Em chỉ đang tưởng tượng mà thôi."

# game/street3.rpy:302
translate viet street3clear_cc194c54:

    # xoai "Ghosts don't exist, and even if they did…"
    xoai "Ma thì vốn dĩ đâu có thật, mà nếu có đi nữa…"

# game/street3.rpy:306
translate viet street3clear_5cf5e57e:

    # xoai "...they certainly wouldn't look like jello skeletons… right?"
    xoai "...thì chắc cũng đâu có xương thạch dẻo như anh… phải không?"

# game/street3.rpy:310
translate viet street3clear_5b5e4260_1:

    # bino "..."
    bino "..."

# game/street3.rpy:314
translate viet street3clear_e2bb06f7:

    # bino "Does it matter?"
    bino "Và điều đó có quan trọng không?"

# game/street3.rpy:318
translate viet street3clear_0b3d4ba3_2:

    # xoai "..."
    xoai "..."

# game/street3.rpy:322
translate viet street3clear_e7cf2368:

    # bino "...Xoai. Even if I'm just in your visions or whatever… You've still learnt something concrete from me. Like, real."
    bino "...Xoài. Dù cho anh có phải chỉ là ảo ảnh trong đầu em hay không… Em vẫn học được nhiều bài học rất thực tế với anh. Đó là thứ có thật."

# game/street3.rpy:326
translate viet street3clear_a6e028a9:

    # bino "That knowledge, you've gotta pass it on, you know? From the ghost world to the real world."
    bino "Kiến thức mà em học được hôm nay, em phải truyền đó nha, biết chưa? Từ dưới này lên trên cõi sống."

# game/street3.rpy:330
translate viet street3clear_66d0f22b:

    # xoai "...yeah."
    xoai "…dạ."

# game/street3.rpy:334
translate viet street3clear_7f700a8d:

    # xoai "I haven't been a good chef today but… I can be a good teacher at least."
    xoai "Hôm nay em là một đầu bếp không được tốt nhưng… ít nhất em sẽ là một người thầy tốt với cả đàn."

# game/street3.rpy:338
translate viet street3clear_f9292aac:

    # xoai "I just wish you were still here with us."
    xoai "Em chỉ ước gì anh còn ở đây với tụi em."

# game/street3.rpy:342
translate viet street3clear_5b5e4260_2:

    # bino "..."
    bino "..."

# game/street3.rpy:344
translate viet street3clear_e666cbf7:

    # bino "I guess there's no easy way around that feeling."
    bino "Anh đoán rằng cũng chẳng có cách nào để vượt qua cảm giác đó một cách dễ dàng."

# game/street3.rpy:348
translate viet street3clear_92ce7843:

    # bino "I'm sorry, Xoai."
    bino "Anh xin lỗi, Xoài."

# game/street3.rpy:352
translate viet street3clear_0b3d4ba3_3:

    # xoai "..."
    xoai "..."

# game/street3.rpy:356
translate viet street3clear_ee92b133:

    # xoai "...It's okay. It's not your fault."
    xoai "…Không sao đâu, anh Bino. Không phải lỗi anh."

# game/street3.rpy:360
translate viet street3clear_82f2e27d:

    # xoai "I'm still sad… but… there's still one thing I need to do."
    xoai "Em vẫn đang buồn…nhưng…vẫn còn một việc em phải làm."

# game/street3.rpy:364
translate viet street3clear_a6e298bc:

    # bino "...and what is it?"
    bino "...nên sao, Xoài?"

# game/street3.rpy:368
translate viet street3clear_39ae1090:

    # xoai "...well…"
    xoai "...ờ thì…"

# game/street3.rpy:372
translate viet street3clear_6b2f6862:

    # xoai "Let's go home first."
    xoai "Mình đi về trước đi."

# game/street3.rpy:376
translate viet street3clear_dff0d46d:

    # bino "...I believe in you."
    bino "...anh tin em."

