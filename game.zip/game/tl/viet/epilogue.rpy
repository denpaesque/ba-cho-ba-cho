﻿# TODO: Translation updated at 2026-10-28 11:10

# game/epilogue.rpy:8
translate viet epilogue_5e2b79b9:

    # story "And so, Xoai, just Xoai, walked home alone, alone through the meandering streets of Saigon…"
    story "Và thế là Xoài, chỉ còn một mình Xoài, một mình rảo bước qua những con phố Sài Gòn ngoằn ngoèo…"

# game/epilogue.rpy:10
translate viet epilogue_884c1768:

    # story "The vision of Bino faded away gently, following Xoai for some last steps…"
    story "Hình bóng của anh Bino mờ dần một cách dịu dàng, dõi theo từng bước chân cuối cùng của Xoài…"

# game/epilogue.rpy:14
translate viet epilogue_8a716280:

    # story "Back at Ba Chieu, Xoai reported back to his pack on the rise of dog poisons around the surrounding areas."
    story "Trở về chợ Bà Chiểu, Xoài báo lại với cả đàn về sự xuất hiện ngày càng nhiều của các loại bả độc ở những khu vực xung quanh."

# game/epilogue.rpy:16
translate viet epilogue_eb17e1a1:

    # story "Xoai taught them his 5 rules for spotting dog baits:"
    story "Xoài truyền lại cho tụi nói 5 quy tắc để nhận biết bả chó:"

# game/epilogue.rpy:20
translate viet epilogue_b1146d19:

    # story "\"1: Do not trust rubber bands!\""
    story "\"1: Không bao giờ tin những thứ buộc dây thun!\""

# game/epilogue.rpy:24
translate viet epilogue_edb82384:

    # story "\"2: Beware of manufactured pellets!\""
    story "\"2: Đề phòng những viên nén công nghiệp!\""

# game/epilogue.rpy:28
translate viet epilogue_64d7aae5:

    # story "\"3: Run from sweet smelling liquids!\""
    story "\"3: Tránh xa những vũng nước có mùi ngọt!\""

# game/epilogue.rpy:32
translate viet epilogue_21fe3a62:

    # story "\"4: Inspect meat carefully!\""
    story "\"4: Kiểm tra thịt thật kỹ trước khi ăn!\""

# game/epilogue.rpy:36
translate viet epilogue_d3cd2bdd:

    # story "\"And last but not least…\""
    story "\"Và điều cuối cùng, nhưng là quan trọng nhất…\""

# game/epilogue.rpy:40
translate viet epilogue_b61439d8:

    # story "\"5: No more scavenging!\""
    story "\"5: Không được bới rác tìm thức ăn nữa!\""

# game/epilogue.rpy:44
translate viet epilogue_1cf1c230:

    # story "Shocked, the pack dogs questioned Xoai. \"How else will we get our food?\", one puppy asked."
    story "Cả đàn bàng hoàng, xôn xao hỏi Xoài. \"Không bới rác thì làm sao tụi mình có cái ăn?\", một con chó nhỏ lên tiếng."

# game/epilogue.rpy:48
translate viet epilogue_cdf53e50:

    # story "\"I'm not sure yet, but what I know for certain is that being on high alert 24/7 will take a toll on us all.\""
    story "\"Mình cũng không biết chắc, nhưng điều mình biết rõ là từ nay là việc lúc nào cũng phải sống trong lo lắng 24/7 sẽ vắt kiệt sức cả đàn.\""

# game/epilogue.rpy:52
translate viet epilogue_539bd680:

    # story "\"We need security. Certainty. Someone to go to for food.\""
    story "\"Chúng ta cần được an toàn. Bền vững. Một ai đó để nương tựa mỗi khi đói.\""

# game/epilogue.rpy:56
translate viet epilogue_71188585:

    # story "\"I know we are strays, and that we want to do things on our own, but it is not worth it when we have to live in fear.\""
    story "\"Mình biết đàn mình là chó hoang, và ai ở đây cũng muốn được tự thân vận động, nhưng điều đó sẽ chẳng đang chút nào khi ngày nào cũng phải sống trong sợ hãi.\""

# game/epilogue.rpy:60
translate viet epilogue_9c72dfd2:

    # story "\"We need to put one last faith in humans.\""
    story "\"Chúng mình cần đặt niềm tin vào con người.\""

# game/epilogue.rpy:64
translate viet epilogue_6bc989b3:

    # story "And so, the day after, Xoai walked around Ba Chieu, going from person to person until…"
    story "Và thế là, ngày hôm sau, Xoài đi quanh chợ Bà Chiểu, tìm đến hết người này tới người khác, tới khi…"

# game/epilogue.rpy:68
translate viet epilogue_c0287e50:

    # story "He met a kind, old man, who offered to take in and feed the dogs each day out of his own pocket."
    story "Cậu gặp một ông lão tốt bụng, người đã ngỏ ý nhận nuôi và tự bỏ tiền túi ra để cho cả đàn được ăn mỗi ngày."

# game/epilogue.rpy:72
translate viet epilogue_2b70504a:

    # story "\"Thank you so much! We are eternally grateful for your kindness!\", Xoai exclaimed."
    story "\"Cảm ơn ông nhiều lắm! Tụi cháu sẽ mãi nhớ đến tấm lòng của ông!\", Xoai reo lên, cảm động."

# game/epilogue.rpy:74
translate viet epilogue_f66456e3:

    # story "And even though the language of barks and woofs could not be translated fully for the comprehension of humans…"
    story "Và dù những tiếng gâu gâu, ẳng ẳng của loài chó chẳng thể nào dịch trọn vẹn ra ngôn ngữ của con người…"

# game/epilogue.rpy:78
translate viet epilogue_9b93bfcf:

    # story "The kind man smiled, knowing in his heart that Xoai and his group were expressing gratitude."
    story "Ông lão tốt bụng vẫn mỉm cười, bởi trong lòng ông hiểu rõ Xoài và đàn chó đang bày tỏ lòng biết ơn sâu sắc."

# game/epilogue.rpy:82
translate viet epilogue_151bdba3:

    # story "In his new home, no longer a cardboard box facing the cold wind..."
    story "Trong ngôi nhà mới của mình, không còn là chiếc hộp carton hứng chịu từng cơn gió lạnh..."

# game/epilogue.rpy:84
translate viet epilogue_cf7ef310:

    # story "Xoai slept soundly for the first time in months, his stomach finally full…"
    story "Lần đầu tiên sau nhiều tháng trời, Xoài đã có một giấc ngủ thật ngon, với cái bụng cuối cùng cũng đã được lấp đầy…"

# game/epilogue.rpy:88
translate viet epilogue_e4d82abb:

    # story "He dreamt of a dog paradise, endless rice fields and sunshine to bask in…"
    story "Cậu mơ về một thiên đường dành cho loài chó, nơi có những cánh đồng lúa bạt ngàn và ánh nắng ấm áp để thỏa thích sưởi mình…"

# game/epilogue.rpy:92
translate viet epilogue_c22446a4:

    # story "In it, he could listen to the sounds of chirping birds…"
    story "Nơi đó, cậu được lắng nghe tiếng chim hót lảnh lót..."

# game/epilogue.rpy:96
translate viet epilogue_133719c3:

    # story "...of swaying leaves…"
    story "...tiếng lá cây rì rào trong gió…"

# game/epilogue.rpy:100
translate viet epilogue_9a637001:

    # story "...and of the pitter patter of another dog's paws, running through the grass."
    story "...và ở đâu đó không xa, tiếng bước chân lách tách của một chú chó khác, đang tung tăng chạy trên thảm cỏ xanh."

# game/epilogue.rpy:103
translate viet epilogue_1d94f05a:

    # story "{i}Fin{/i}"
    story "{i}Fin{/i}"

