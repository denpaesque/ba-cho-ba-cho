﻿# TODO: Translation updated at 2026-10-28 11:10

# game/street2.rpy:13
translate viet street2_3128a3b1:

    # xoai "Hey, this looks promising!"
    xoai "Nè anh, chỗ này nhìn tiềm năng đó!"

# game/street2.rpy:17
translate viet street2_8496ca05:

    # xoai "And it's by a cool-looking railway too!! Jackpot!!"
    xoai "Ngay cạnh đường ray siêu ngầu luôn!! Trúng tủ rồi!!"

# game/street2.rpy:21
translate viet street2_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street2.rpy:25
translate viet street2_c095d577:

    # xoai "Say, Bino, you sure you're not busy or something?"
    xoai "Mà anh Bino, anh có đang bận gì không đấy?"

# game/street2.rpy:29
translate viet street2_af159fc9:

    # xoai "I just hope I'm not bothering you too much…"
    xoai "Em chỉ mong em đang không làm phiền anh nhiều quá thôi…"

# game/street2.rpy:33
translate viet street2_8f70c8dd:

    # xoai "I know how to spot those evil pellets and pouches now, so don't worry!"
    xoai "Em biết cách phát hiện mấy cái miếng bả độc hại rồi, nên anh không cần quá lo cho em đâu!"

# game/street2.rpy:37
translate viet street2_ff7c4f77:

    # bino "Well, you can never be too careful, Xoài."
    bino "Ừ, nhưng cẩn thận không bao giờ là thừa đâu, Xoài."

# game/street2.rpy:41
translate viet street2_c1951371:

    # bino "...besides, there's not much to do in the ghost realm."
    bino "…mà dưới cõi âm cũng đâu có gì vui."

# game/street2.rpy:45
translate viet street2_8c14e5ad:

    # xoai "Ahh… right…"
    xoai "À… phải rồi…"

# game/street2.rpy:49
translate viet street2_ceabf07e:

    # xoai "...you're not here anymore."
    xoai "... anh đâu còn ở trên đây."

# game/street2.rpy:53
translate viet street2_0b3d4ba3_1:

    # xoai "..."
    xoai "..."

# game/street2.rpy:57
translate viet street2_74e7791f:

    # xoai "Why is that? I didn't think to ask in the moment…"
    xoai "Mà tại sao vậy, anh Bino? Lúc mới gặp lại anh em chưa kịp hỏi…"

# game/street2.rpy:61
translate viet street2_de629475:

    # xoai "Truth is, we never know what became of you."
    xoai "Tụi em cũng chẳng biết rốt cuộc chuyện gì đã xảy ra với anh."

# game/street2.rpy:65
translate viet street2_5b5e4260:

    # bino "..."
    bino "..."

# game/street2.rpy:69
translate viet street2_81c36ff2:

    # bino "Ate something bad, that's all."
    bino "Anh ăn phải thuốc độc thôi."

# game/street2.rpy:73
translate viet street2_6bbba708:

    # xoai "Ah..."
    xoai "À…"

# game/street2.rpy:77
translate viet street2_17909a87:

    # bino "...don't worry about it. We've got food to find, right?"
    bino "... thôi đừng lo. Em vẫn phải đi tìm đồ ăn mà, phải không?"

# game/street2.rpy:79
translate viet street2_0b3d4ba3_2:

    # xoai "..."
    xoai "..."

# game/street2.rpy:83
translate viet street2_f22e1636:

    # xoai "Yeah, you're right."
    xoai "Dạ, anh nói đúng."

# game/street2.rpy:161
translate viet ba4_6193651e:

    # xoai "Dog food! It's as if it were fate…"
    xoai "Đồ ăn cho chó kìa! Như duyên trời định vậy…"

# game/street2.rpy:165
translate viet ba4_8b9ae9ba:

    # xoai "And the human left it in a bowl for us!! How nice…"
    xoai "Mà người ta còn để sẵn trong chén cho tụi mình nữa chứ!! Tốt bụng quá đi…"

# game/street2.rpy:167
translate viet ba4_dee5b6f4:

    # bino "*inspecting noises*"
    bino "*ngửi ngửi, kiểm tra*"

# game/street2.rpy:171
translate viet ba4_f0812c4b:

    # bino "Well, this is all good."
    bino "Cái này sạch đấy."

# game/street2.rpy:175
translate viet ba4_eb2ab0f7:

    # bino "But now, now… it could be for another dog…"
    bino "Nhưng mà biết đâu là phần của con chó khác thì sao…"

# game/street2.rpy:179
translate viet ba4_e55f3bd2:

    # xoai "Aww man…"
    xoai "Chán vậy…"

# game/street2.rpy:183
translate viet ba4_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street2.rpy:187
translate viet ba4_4d705d04:

    # xoai "…but a bite really wouldn't hurt…"
    xoai "...mà chắc ăn ké một miếng cũng không sao đâu nhỉ…"

# game/street2.rpy:191
translate viet ba4_c4890f5a:

    # xoai "...hungryy…"
    xoai "...đói quá…"

# game/street2.rpy:195
translate viet ba4_22d2f29e:

    # bino "...sure."
    bino "...thôi cũng được."

# game/street2.rpy:199
translate viet ba4_99616bda:

    # xoai "Yay!!"
    xoai "Ye!!"

# game/street2.rpy:203
translate viet ba4_4a9b1f42:

    # xoai "*slurp*"
    xoai "*xực xực*"

# game/street2.rpy:207
translate viet ba4_eb54fbfc:

    # bino "Eat a bit slower, will ya??"
    bino "Trời ơi, ăn từ từ thôi!!" 

# game/street2.rpy:229
translate viet ba5_aaf0f514:

    # xoai "These weird lollipops again! They don't even smell good…"
    xoai "Lại mấy cây kẹo mút giả này nữa! Lần này mùi cũng chẳng thơm…"

# game/street2.rpy:233
translate viet ba5_c6f817cb:

    # bino "Yep. Same deal. That pouch-shaped thing at the end? Red flag…"
    bino "Ừ. Chiêu cũ thôi. Thấy cái miếng nhìn giống gói ở phía đuôi không? Báo động đỏ đó."

# game/street2.rpy:237
translate viet ba5_13610c9f:

    # xoai "Hah! You mean a yellow flag!"
    xoai "Haha! Ý anh là báo động vàng chứ!"

# game/street2.rpy:239
translate viet ba5_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street2.rpy:243
translate viet ba5_db32e5b0:

    # xoai "...get it? Because red and yellow look the same to us…?"
    xoai "… hiểu không? Tại đối với loài chó mình thì đỏ với vàng giống hệt nhau mà…?"

# game/street2.rpy:247
translate viet ba5_33e8a744:

    # bino "It's a human expression, Xoài."
    bino "Thành ngữ của loài người mà, Xoài."

# game/street2.rpy:251
translate viet ba5_6f8b09bd:

    # xoai "I KNOW!!"
    xoai "EM BIẾT!! GIỠN XÍU CŨNG KHÔNG CHO..."

# game/street2.rpy:273
translate viet ba6_e42bee47:

    # xoai "A sausage!! Hooray!!"
    xoai "Một cây xúc xích nè!! Ye!!"

# game/street2.rpy:277
translate viet ba6_cb1aea95:

    # bino "Hey, those are unhealthy as hell! No need to eat junk food like this..."
    bino "Nè, mấy cái đó ăn vô bổ lắm! Làm gì mà phải ăn vặt kiểu này..."

# game/street2.rpy:281
translate viet ba6_2ee7bd0a:

    # xoai "You're right… but we are kind of starving, though…"
    xoai "Anh nói cũng đúng… nhưng em đang đói kiệt sức rồi…"

# game/street2.rpy:285
translate viet ba6_d1548f0c:

    # bino "Let's look around more."
    bino "Tìm quanh đây thêm chút nữa đi."

# game/street2.rpy:289
translate viet ba6_c000ebc3:

    # bino "Besides… I think there's some bad stuff hidden in the sausage."
    bino "Với lại… anh nghĩ bên trong cây xúc xích này có giấu mấy thứ xấu đó."

# game/street2.rpy:294
translate viet ba6_07ede12e:

    # bino "Look. That powder thing… Bad news, Xoài."
    bino "Nhìn kỹ nha. Có lớp bột kìa… Không xong rồi nha, Xoài."

# game/street2.rpy:298
translate viet ba6_4a6d02c2:

    # xoai "Oh wait.. you're right. I could barely see!"
    xoai "Ôi khoan đã… anh nói đúng ghê. Em nhìn gần như không thấy luôn đó!"

# game/street2.rpy:302
translate viet ba6_2dec6de9:

    # bino "I guess that's the point…"
    bino "Thì bọn nó muốn vậy mà…"

# game/street2.rpy:306
translate viet ba6_51c3e399:

    # bino "That stuff is called cyanide, I think. Sometimes they use sulfur, but either way, both substances are poisonous."
    bino "Hình như lớp bột đó là chất xyanua đó. Cũng có lúc bọn nó dùng lưu huỳnh, nhưng kiểu gì thì cả hai thứ đó đều cực độc hại." 

# game/street2.rpy:311
translate viet ba6_85f8c869:

    # bino "And so they count on us to not notice these in the food..."
    bino "Và bọn nó cho là mình không để ý rồi nuốt chửng cây xúc xích độc luôn…"

# game/street2.rpy:315
translate viet ba6_c79553ce:

    # xoai "Would someone really go this far to poison a rat?"
    xoai "Ai mà cất công đến mức này để bẫy chuột nhỉ?"

# game/street2.rpy:319
translate viet ba6_5b5e4260:

    # bino "..."
    bino "..."

# game/street2.rpy:323
translate viet ba6_1ce90dcc:

    # bino "They want to poison more than rats, sometimes…"
    bino "Đôi khi họ không chỉ muốn đánh bả chuột đâu…"

# game/street2.rpy:327
translate viet ba6_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street2.rpy:331
translate viet ba6_cc5cf951:

    # xoai "Oh…"
    xoai "Ồ…"

# game/street2.rpy:351
translate viet street2clear_915cb543:

    # xoai "Ahh, I feel bad… I ate all of the dog food we found…"
    xoai "Em thấy ấy náy quá… tại lúc nãy em ăn sạch đồ ăn mình tìm được rồi…"

# game/street2.rpy:355
translate viet street2clear_35f0d3ff:

    # bino "Well, take care of yourself first. How else are you gonna run around and find food for everyone?"
    bino "Dù sao thì cũng phải lo cho cái thân trước mà. Không thì sức đâu đi tìm đồ ăn cho cả đàn?"

# game/street2.rpy:359
translate viet street2clear_a1fa878b:

    # xoai "I'm young, I have energy!!"
    xoai "Em còn trẻ, còn sức!!"

# game/street2.rpy:363
translate viet street2clear_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street2.rpy:367
translate viet street2clear_fb061516:

    # xoai "...on second thought… I'm a bit tired."
    xoai "…à mà nghĩ lại thì… em hơi mệt thật."

# game/street2.rpy:371
translate viet street2clear_f44432c3:

    # bino "That's what I thought…"
    bino "Biết ngay mà…"

# game/street2.rpy:375
translate viet street2clear_3785c631:

    # bino "One more street, okay? I know you don't like to give up halfway."
    bino "Thêm một con phố nữa thôi nha? Anh biết em không thích bỏ cuộc khi chưa xong việc."

# game/street2.rpy:379
translate viet street2clear_66d0f22b:

    # xoai "...yeah."
    xoai "…dạ."

# game/street2.rpy:383
translate viet street2clear_ffc942ad:

    # xoai "But honestly… I'm not really tired from walking around…"
    xoai "Thật ra… em không mệt tại vì phải đi bộ quanh đây đâu…"

# game/street2.rpy:387
translate viet street2clear_bdb520ea:

    # xoai "I'm just… kinda tired that we have to keep looking out for these poisons."
    xoai "Em chỉ… hơi kiệt sức vì lúc nào cũng phải rình xem đồ ăn trên đường có bả không."

# game/street2.rpy:391
translate viet street2clear_368bf5c0:

    # xoai "...It's like we can't trust anyone out here."
    xoai "… như thể mình không được tin tưởng bất kỳ ai ở ngoài đường." 

# game/street2.rpy:395
translate viet street2clear_a5be42f7:

    # xoai "Just one mistake, and…"
    xoai "Tại chỉ cần một sơ suất là..."

# game/street2.rpy:399
translate viet street2clear_5b5e4260:

    # bino "..."
    bino "..."

# game/street2.rpy:403
translate viet street2clear_0b3d4ba3_1:

    # xoai "..."
    xoai "..."

# game/street2.rpy:407
translate viet street2clear_571d7de9:

    # xoai "I just don't want what happened to you to happen to anyone again, Bino…"
    xoai "Em chỉ không muốn thấy cảnh ai khác bị như anh thôi, anh Bino à…"

# game/street2.rpy:411
translate viet street2clear_b736dadb:

    # xoai "It's… hard to believe that people really want to poison dogs…"
    xoai "Em… thấy khó tin rằng nhiều người thật sự muốn đầu độc chó…"

# game/street2.rpy:415
translate viet street2clear_83babc99:

    # xoai "I guess I am just naive after all…"
    xoai "Nên có lẽ em vẫn còn là một đứa ngây thơ thôi…"

# game/street2.rpy:419
translate viet street2clear_c2e085e1:

    # bino "...well, I guess now I don't have to break the news to you as to why I'm a ghost."
    bino "...ít ra thì anh cũng không cần phải giải thích với em tại sao anh là hồn ma nữa."

# game/street2.rpy:423
translate viet street2clear_6ce63601:

    # bino "But, it's not every human, Xoai. Just be on the lookout, is all."
    bino "Không phải con người nào cũng vậy đâu, Xoài. Chỉ cần cảnh giác là được, vậy thôi."

# game/street2.rpy:427
translate viet street2clear_db3f6da7:

    # xoai "I know, but still…"
    xoai "Em biết, nhưng…"

# game/street2.rpy:431
translate viet street2clear_a6a92009:

    # xoai "I'm… scared."
    xoai "Em… sợ."

# game/street2.rpy:435
translate viet street2clear_5b5e4260_1:

    # bino "..."
    bino "..."

# game/street2.rpy:437
translate viet street2clear_c8727b73:

    # bino "I get you."
    bino "Anh hiểu mà."

# game/street2.rpy:441
translate viet street2clear_c62f7f7e:

    # bino "I guess it's easy for me to say… because I'm already dead."
    bino "Mà chắc anh nói cũng dễ hơn em… tại anh đã chết rồi."

# game/street2.rpy:445
translate viet street2clear_820cb9dd:

    # bino "I can't exactly die twice, so…"
    bino "Chết rồi không chết lại được…"

# game/street2.rpy:449
translate viet street2clear_c5dabb42:

    # bino "...but, for you… that fear of dying just from eating one bad thing…"
    bino "...nhưng anh hiểu với em thì… ăn sai một thứ là…"

# game/street2.rpy:453
translate viet street2clear_98eaecd9:

    # xoai "...yeah. You get it."
    xoai "...Ừ. Em biết anh hiểu mà."

# game/street2.rpy:455
translate viet street2clear_5b5e4260_2:

    # bino "..."
    bino "..."

# game/street2.rpy:459
translate viet street2clear_4110439b:

    # bino "I'm here with you."
    bino "Anh luôn ở đây cạnh em."

# game/street2.rpy:463
translate viet street2clear_0d9b44f4:

    # bino "Always and forever. Remember that."
    bino "Mãi mãi là như vậy. Nhớ nha."

# game/street2.rpy:467
translate viet street2clear_0b3d4ba3_2:

    # xoai "..."
    xoai "..."

# game/street2.rpy:471
translate viet street2clear_1144ff72:

    # bino "One more street, okay?"
    bino "Thêm một con phố nữa thôi nha?"

# game/street2.rpy:473
translate viet street2clear_0b3d4ba3_3:

    # xoai "..."
    xoai "..."

# game/street2.rpy:477
translate viet street2clear_376e0fec:

    # xoai "Okay."
    xoai "Dạ."

