﻿# TODO: Translation updated at 2026-10-28 11:10

# game/street1.rpy:12
translate viet street1_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street1.rpy:16
translate viet street1_38e86c99:

    # xoai "Oof, I travelled too far out…"
    xoai "Hùm, đi ra tới tuốt đây rồi…"

# game/street1.rpy:20
translate viet street1_1cf6ec3f:

    # xoai "Well whatever..."
    xoai "Mà thôi..."

# game/street1.rpy:24
translate viet street1_0bc04d52:

    # xoai "The market people are extra busy today, so I shouldn't be bothering them as much anyway…"
    xoai "Hôm nay ở chợ người ta cũng bận hơn thường, nên mình cũng không nên làm phiền họ nhiều…"

# game/street1.rpy:28
translate viet street1_2f49f32b:

    # xoai "Now, let's see where we can find food…"
    xoai "Kiếm ăn ở đâu đây ta…"

# game/street1.rpy:30
translate viet street1_3a39f22c:

    # xoai "*scavenging*"
    xoai "*lục lọi*"

# game/street1.rpy:34
translate viet street1_b6c547c9:

    # xoai "Eh? What's this?"
    xoai "Hử? Cái gì đây?"

# game/street1.rpy:39
translate viet street1_d968d1c5:

    # xoai "This stuff is candy, right?"
    xoai "Chắc đây là kẹo đúng không?"

# game/street1.rpy:43
translate viet street1_531e72e5:

    # xoai "I see humans eating these all the time…"
    xoai "Mình thấy con người ăn mấy cái này suốt mà…"

# game/street1.rpy:47
translate viet street1_0b3d4ba3_1:

    # xoai "..."
    xoai "..."

# game/street1.rpy:51
translate viet street1_fd61fe99:

    # xoai "Well what do you know! It's our lucky day to try a new cuisine."
    xoai "Chà, hôm nay vậy mà gặp may! Được thử món mới rồi."

# game/street1.rpy:55
translate viet street1_7be67010:

    # xoai "I should probably taste test it first though.."
    xoai "Mình nên nếm thử một miếng trước đã…"

# game/street1.rpy:59
translate viet street1_900232a1:

    # xoai "Here goes nothin-"
    xoai "Thôi, làm liều vậy-"

# game/street1.rpy:63
translate viet street1_35dbdf71:

    # unknown "DON'T EAT IT!!!"
    unknown "ĐỪNG ĂN CÁI ĐÓ!!!!"

# game/street1.rpy:67
translate viet street1_0943f258:

    # xoai "Ehh!?????"
    xoai "Hả!?????"

# game/street1.rpy:72
translate viet street1_13b70412:

    # unknownfocus "Xoài!!! It's me!!! You remember me, right??"
    unknownfocus "Xoài!!! Là anh đây mà!!! Còn nhớ anh không??"

# game/street1.rpy:77
translate viet street1_2fe1c982:

    # xoai "Ehh?? No?? What?? Wait.."
    xoai "Hả??? Không?? Ai?? Ủa…"

# game/street1.rpy:82
translate viet street1_0b3d4ba3_2:

    # xoai "..."
    xoai "..."

# game/street1.rpy:87
translate viet street1_281fc696:

    # xoai "Bino? Is that you??"
    xoai "Bino? Là anh đó hả??"

# game/street1.rpy:92
translate viet street1_b3fc8416:

    # bino "Yep! Uh, don't mind the not-so-corporeal form…"
    bino "Anh đây! Ờ, anh biết anh trông hơi kỳ…"

# game/street1.rpy:97
translate viet street1_49e45386:

    # xoai "No worries… I won't question it…"
    xoai "Không sao, anh Bino… em không thắc mắc đâu…"

# game/street1.rpy:102
translate viet street1_0b3d4ba3_3:

    # xoai "..."
    xoai "..."

# game/street1.rpy:107
translate viet street1_705b4bd0:

    # xoai "Hey, if you wanted the candy for yourself, you could have just told me!!"
    xoai "Ủa, mà nếu anh muốn ăn miếng kẹo này thì cứ hỏi em, sao phải hù em vậy!!"

# game/street1.rpy:113
translate viet street1_07d93760:

    # bino "It's not that!! It's poison, Xoài.."
    bino "Không phải!! Là bả đó, Xoài ơi…"

# game/street1.rpy:119
translate viet street1_fca49e6f:

    # xoai "Ehh? Poison? Why here??"
    xoai "Bả hả? Sao lại để trên đường vậy trời??"

# game/street1.rpy:125
translate viet street1_74e2f52e:

    # bino "It's for the rats. People kind of want to get rid of them. Rodenticides and whatnot."
    bino "Để giết chuột đó. Con người muốn dọn sạch bọn nó khỏi đường phố. Nên dùng thuốc giết chuột các thứ."

# game/street1.rpy:132
translate viet street1_5b25456a:

    # xoai "Ah ok, these aren't for us then!"
    xoai "Vậy thì được, mấy cái này không dành cho tụi mình!"

# game/street1.rpy:138
translate viet street1_388f4ff7:

    # xoai "Jeez.."
    xoai "Hết hồn…"

# game/street1.rpy:144
translate viet street1_fdb91d4c:

    # xoai "You scared me for a moment there, Bino! I thought there were people actually out to get us!!"
    xoai "Làm em giật mình nha, anh Bino! Hồi nãy em tưởng có ai muốn làm hại tụi mình chứ!!"

# game/street1.rpy:150
translate viet street1_5b5e4260:

    # bino "..."
    bino "..."

# game/street1.rpy:156
translate viet street1_b79ae52d:

    # bino "Well, about that…"
    bino "Nói đúng thì…"

# game/street1.rpy:162
translate viet street1_5b5e4260_1:

    # bino "..."
    bino "..."

# game/street1.rpy:168
translate viet street1_5a3526c4:

    # bino "...nevermind. You're scavenging, right? I can just be on the lookout for you."
    bino "...thôi kệ đi. Em đang đi kiếm ăn phải không? Để anh đi rình phụ em."

# game/street1.rpy:174
translate viet street1_4ca63b49:

    # xoai "Aww, thanks so much Bino!! You're the best…"
    xoai "Em cảm ơn anh nhiều nha, anh Bino!! Anh quá tuyệt vời…"

# game/street1.rpy:180
translate viet street1_f7b4250c:

    # xoai "I've missed you all this time, you know!! It just hasn't been the same.."
    xoai "Anh biết là em nhớ anh lắm luôn đó!! Mọi thứ không còn như xưa nữa…"

# game/street1.rpy:186
translate viet street1_9dc9b835:

    # xoai "...so it's nice that you're here now, like the old days…"
    xoai "...nên có anh ở đây với em, em vui lắm, cứ như hồi nào…"

# game/street1.rpy:192
translate viet street1_5b5e4260_2:

    # bino "..."
    bino "..."

# game/street1.rpy:198
translate viet street1_34969af8:

    # bino "Bit too sappy."
    bino "Hơi sến rồi nha, Xoài."

# game/street1.rpy:204
translate viet street1_e96a9630:

    # xoai "Teehee, sorry…"
    xoai "Hihi, lỡ thôi…"

# game/street1.rpy:210
translate viet street1_e26d7943:

    # xoai "Well, now that we're this far out, we might as well continue searching around here!"
    xoai "Mà đã lặn lội qua đây rồi, chắc mình tranh thủ lục lọi quanh đây nha!"

# game/street1.rpy:216
translate viet street1_87655e58:

    # xoai "I'll just look around for more food, 'kay? I've got the whole pack to feed!"
    xoai "Em đi tìm thêm đồ ăn đây, anh! Cả đàn đang chờ em đó!"

# game/street1.rpy:221
translate viet street1_b3318f22:

    # bino "Right there with ya."
    bino "Anh đang ngay sau đuôi em đây thôi mà."

# game/street1.rpy:302
translate viet ba1_7aaf57e7:

    # xoai "Hey!! A chunk of beef!!"
    xoai "Một miếng thịt nè!!"

# game/street1.rpy:306
translate viet ba1_5d45b856:

    # xoai "It's small, but it'll do. We're missing some actual proteins after all…"
    xoai "Em thấy hơi nhỏ nhưng chịu thôi. Dù sao thì mình cũng đang thiếu đạm mà…"

# game/street1.rpy:310
translate viet ba1_3a891b8a:

    # bino "That's a bad one, Xoài."
    bino "Miếng này nguy hiểm đó nha, Xoài."

# game/street1.rpy:314
translate viet ba1_7c9276dc:

    # bino "Look closer. Don't you see anything wrong?"
    bino "Em nhìn kỹ vào miếng thịt đi. Không thấy có gì bất thường à?"

# game/street1.rpy:318
translate viet ba1_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street1.rpy:322
translate viet ba1_ad04f927:

    # xoai "Not really, no."
    xoai "Dạ em không thấy lắm."

# game/street1.rpy:327
translate viet ba1_fabcc974:

    # bino "This pouch, right here. It's poison, Xoài!"
    bino "Có cái gói nhỏ bên trong miếng thịt, thấy không? Là bả đó, Xoài!"

# game/street1.rpy:331
translate viet ba1_6949f0f4:

    # bino "The humans think they are smart for sneaking it into meat like this."
    bino "Bọn con người giấu vào một cục thịt kiểu này rồi tưởng mình khôn."

# game/street1.rpy:336
translate viet ba1_fc62dd42:

    # xoai "Ehh!! Why would they do that?"
    xoai "Ủa?! Tại sao họ lại làm vậy?"

# game/street1.rpy:340
translate viet ba1_5bf1cd47:

    # bino "So it attracts animals. Cuz we like meat, y'know."
    bino "Để dụ động vật. Tại tụi mình thích ăn thịt mà."

# game/street1.rpy:344
translate viet ba1_ba204187:

    # bino "These pouches are bad business for us."
    bino "Mấy cái gói này nguy hiểm cực kỳ cho loài mình đó."

# game/street1.rpy:348
translate viet ba1_4997d249:

    # xoai "Jeez…"
    xoai "Trời ơi…"

# game/street1.rpy:352
translate viet ba1_d13fc043:

    # xoai "It's as if they're tailoring these poisons for dogs…"
    xoai "Cứ như họ chế mấy cái này dành riêng cho tụi mình vậy…"

# game/street1.rpy:356
translate viet ba1_5b5e4260:

    # bino "..."
    bino "..."

# game/street1.rpy:360
translate viet ba1_5b5e4260_1:

    # bino "..."
    bino "..."

# game/street1.rpy:382
translate viet ba2_88db4b03:

    # xoai "What the hell is this thing? It smells kinda nice, but it looks suspicious…"
    xoai "Cái này là gì vậy anh? Mùi thơm quá, nhưng nhìn cũng thấy nghi nghi…"

# game/street1.rpy:384
translate viet ba2_9782416a:

    # bino "One of these 'lollipop' baits."
    bino "Một loại bả 'kẹo mút' đó."

# game/street1.rpy:388
translate viet ba2_5f5146fc:

    # bino "The 'candy' part is what's meant to be eaten, filled with both meat and poison."
    bino "Phần 'kẹo' là cái chúng nó muốn mình ăn, bên trong trộn thịt với bả."

# game/street1.rpy:390
translate viet ba2_ff43e95b:

    # bino "And the thin 'handle' is for the humans to hold them safely."
    bino "Còn cái miếng mỏng bên dưới là để bọn con người cầm cho an toàn."

# game/street1.rpy:394
translate viet ba2_04d3e106:

    # xoai "Ouch…"
    xoai "Ui…"

# game/street1.rpy:398
translate viet ba2_dddcef35:

    # xoai "So they make it safe for them, but dangerous for animals like us, huh…"
    xoai "Vậy họ làm nó an toàn cho họ, nhưng nguy hiểm cho loài mình, nhỉ…"

# game/street1.rpy:402
translate viet ba2_9f0dadd7:

    # bino "Yeah, unfortunately."
    bino "Ừ, tệ vậy đó."

# game/street1.rpy:424
translate viet ba3_70113ab0:

    # xoai "Another one of these evil rat poison candies! The weird pellet shape says it all!"
    xoai "Lại thêm một miếng kẹo bả chuột quái quỷ nè anh! Thấy nó giống viên nén là biết ngay!!"

# game/street1.rpy:428
translate viet ba3_6a638172:

    # bino "Exactly! You're getting the hang of this."
    bino "Chính xác! Em bắt đầu quen tay rồi đó."

# game/street1.rpy:432
translate viet ba3_63aa7f7d:

    # xoai "Don't worry, it's nothing. They stick out like a sore thumb to me now."
    xoai "Đâu có gì đâu, anh. Bây giờ em nhìn là biết liền mà."

# game/street1.rpy:436
translate viet ba3_8016617c:

    # xoai "Still, I should take note of these and tell the gang to avoid them."
    xoai "Nhưng em vẫn ghi nhớ mấy loại này để dặn tụi trong đàn còn biết đường mà tránh."

# game/street1.rpy:440
translate viet ba3_60a2ec0b:

    # xoai "It only takes one mistake, after all…"
    xoai "Tại chỉ cần sơ suất một lần là tiêu…"

# game/street1.rpy:442
translate viet ba3_5b5e4260:

    # bino "..."
    bino "..."

# game/street1.rpy:446
translate viet ba3_ea333f32:

    # bino "Yeah, one mistake…"
    bino "Ừ, chỉ một lỗi nhỏ…"

# game/street1.rpy:466
translate viet street1clear_0b3d4ba3:

    # xoai "..."
    xoai "..."

# game/street1.rpy:470
translate viet street1clear_4f5891fc:

    # xoai "Wow, this alleyway has nothing."
    xoai "Ui, con hẻm này chả có gì hết."

# game/street1.rpy:474
translate viet street1clear_3c023d98:

    # bino "We better look somewhere else then."
    bino "Vậy mình nên đi chỗ khác tìm thôi."

# game/street1.rpy:478
translate viet street1clear_b1fd0dfc:

    # bino "You lead the way."
    bino "Em dẫn đường đó."

# game/street1.rpy:482
translate viet street1clear_2bd4b632:

    # xoai "Okay!! This way!"
    xoai "Dạ!! Đi theo em!"

