﻿# TODO: Translation updated at 2026-10-28 11:10

translate viet strings:

    # game/options.rpy:14
    old "bachobacho"
    new "bachobacho"

