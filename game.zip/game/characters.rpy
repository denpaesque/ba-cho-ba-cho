# Declare characters used by this game. The color argument colorizes the
# name of the character.

define xoai = Character(_("Xoai"), color="c58140", callback = name_callback, cb_name = "xoai")
define bino = Character("Bino", color="b07ee5", callback = name_callback, cb_name = "bino")
define unknown = Character("???", color="ffffff")
define unknownfocus = Character("???", color="ffffff", callback = name_callback, cb_name = "bino")
define story = Character(None, what_xalign=0.5, what_text_align=0.5, window_background=None)
define endcredits = Character(None, kind=nvl, what_xalign=0.5, what_text_align=0.5, window_background=None)

# move all character sprites up
transform default:
    yalign 0.4 
    xalign 0.5

define config.default_transform = default

transform left:
    yalign 0.4
    xalign 0.0

transform right:
    yalign 0.4
    xalign 1.0

transform center:
    yalign 0.5
    xalign 0.5