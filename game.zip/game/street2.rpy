label street2:
    
    scene street2
    with Fade(0.5, 1, 0.5)

    show xoai mouthopenhappy eyesopenneutral at right, entrance
    show bino eyesopenneutral at left, entrance
    
    pause 0.3

    window show

    xoai "Hey, this looks promising!"
    
    show xoai mouthtongue eyesclosedhappy -emanatasurprise

    xoai "And it's by a cool-looking railway too!! Jackpot!!"

    show xoai eyesopenaverted mouthcloseddot -emanatasurprise -browsneutral

    xoai "..."

    show xoai mouthopenhappy emanatasweat emotesweat

    xoai "Say, Bino, you sure you're not busy or something?"

    show xoai eyesclosedsad mouth3 -emanatasweat

    xoai "I just hope I'm not bothering you too much…"

    show xoai eyessurprisedangry emanatasurprise -emotesweat at up

    xoai "I know how to spot those evil pellets and pouches now, so don't worry!"

    show bino eyesclosedrelaxed

    bino "Well, you can never be too careful, Xoài."

    show bino eyesclosedsad emotesweat

    bino "...besides, there's not much to do in the ghost realm."

    show xoai eyesopensad mouthcloseddot -emanatasurprise -browsangry

    xoai "Ahh… right…"

    show xoai mouthopeno

    xoai "...you're not here anymore."

    show xoai mouthclosedwobble

    xoai "..."

    show xoai mouthopeno eyesopenneutral at up

    xoai "Why is that? I didn't think to ask in the moment…"

    show xoai eyesclosedsad mouthopenwobble

    xoai "Truth is, we never know what became of you."

    show bino eyesopensad -emotedarkness -emotesweat

    bino "..."

    show bino emanatadown eyesclosedsad

    bino "Ate something bad, that's all."

    show xoai eyesopenneutral -browssad

    xoai "Ah..."

    show bino eyesopensad -emanatadown at up

    bino "...don't worry about it. We've got food to find, right?"

    xoai "..."

    show xoai eyesclosedhappy mouth3 emoteblush

    xoai "Yeah, you're right."

    window hide 

    show xoai at exit
    show bino at exit

    # initialise ba discovered to false
    $ ba4found = ba5found = ba6found = False

    jump street2search

label street2search:
    
    $ street2allfound = ba4found * ba5found * ba6found

    if street2allfound == True:
        pause 0.3
        scene street2
        with Fade(0.5, 1, 0.5)
        jump street2clear
    else:
        pause 0.3
        scene street2
        with Fade(0.5, 1, 0)
        call screen street2

screen street2:

    fixed:

        imagebutton:
            xpos 1250
            ypos 800
            focus_mask True
            idle "ba/street2kibble.png"
            hover "ba/street2kibble_hover.png"
            at ba50
            sensitive ba4found == False
            action [SetVariable("ba4found", True), Jump("ba4")]
            if ba4found:
                at grey, ba50
            
        imagebutton:
            xpos 1700
            ypos 800
            focus_mask True
            idle "ba/street2lollipop.png"
            hover "ba/street2lollipop_hover.png"
            at ba50
            sensitive ba5found == False
            action [SetVariable("ba5found", True), Jump("ba5")]
            if ba5found:
                at grey, ba50
            
        imagebutton:
            xpos 800
            ypos 940
            focus_mask True
            idle "ba/street2sausage.png"
            hover "ba/street2sausage_hover.png"
            at ba50
            sensitive ba6found == False
            action [SetVariable("ba6found", True), Jump("ba6")]
            if ba6found:
                at grey, ba50

label ba4:

    show street2kibble at center, inspection_start
    pause 0.3

    show xoai emanatasurprise eyessurprisedneutral mouth3 emoteblush -browsneutral -browssad at right, entrance
    show bino eyesopenneutral at left, entrance
    pause 0.2

    window show

    xoai "Dog food! It's as if it were fate…"

    show xoai eyesclosedsad -emanatasurprise at bounce

    xoai "And the human left it in a bowl for us!! How nice…"

    bino "*inspecting noises*"

    show bino eyesclosedhappy emanatasurprise at bounce

    bino "Well, this is all good."

    show bino eyessurprisedannoyed emanatasweat -emanatasurprise at down

    bino "But now, now… it could be for another dog…"

    show xoai eyesopensad emotesweat mouthopeno -emoteblush at down

    xoai "Aww man…"

    show xoai mouthcloseddot

    xoai "..."

    show xoai eyesclosedsad emoteblush mouthopenhappier -emotesweat at up

    xoai "…but a bite really wouldn't hurt…"

    show xoai mouthopenhappy

    xoai "...hungryy…"

    show bino eyesclosedrelaxed -emanatasweat -emotesweat at up

    bino "...sure."

    show xoai eyessurprisedneutral mouth3 emanatasurprise

    xoai "Yay!!"

    show xoai mouthopendrool -emanatasurprise

    xoai "*slurp*"

    show bino eyessurprisedangry emanataangry

    bino "Eat a bit slower, will ya??"

    window hide

    show xoai at exit
    show bino at exit

    show street2kibble at inspection_end

    jump street2search

label ba5:

    show street2lollipop at center, inspection_start
    pause 0.3

    show xoai eyesclosedneutral mouthclosedwobble emanataangry at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance
    pause 0.2

    window show

    xoai "These weird lollipops again! They don't even smell good…"

    show bino eyesclosedneutral

    bino "Yep. Same deal. That pouch-shaped thing at the end? Red flag…"

    show xoai eyesclosedexcited mouthopenhappier -emanataangry

    xoai "Hah! You mean a yellow flag!"

    xoai "..."

    show xoai emotesweat at down

    xoai "...get it? Because red and yellow look the same to us…?"

    show bino eyessurprisedannoyed

    bino "It's a human expression, Xoài."

    show xoai emanataangry eyessurprisedannoyed -emotesweat at bounce

    xoai "I KNOW!!"

    window hide

    show xoai at exit
    show bino at exit

    show street2lollipop at inspection_end

    jump street2search

label ba6:

    show street2sausage at center, inspection_start
    pause 0.3

    show xoai eyesopenangry mouthopenhappier emanatasurprise -emanataangry at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance
    pause 0.2

    window show

    xoai "A sausage!! Hooray!!"

    show bino eyesclosedsad -emoteblush

    bino "Hey, those are unhealthy as hell! No need to eat junk food like this..."

    show xoai eyesclosedsad mouth3 emoteblush -emanatasurprise

    xoai "You're right… but we are kind of starving, though…"

    show bino eyesclosedangry

    bino "Let's look around more."

    show bino eyesopensad

    bino "Besides… I think there's some bad stuff hidden in the sausage."

    show bino eyesopenneutral
    show street2sausage at inspect_zoom_in

    bino "Look. That powder thing… Bad news, Xoài."

    show xoai mouthopeno eyessurprisedneutral -emoteblush at bounce

    xoai "Oh wait.. you're right. I could barely see!"

    show bino eyesclosedsad emotesweat

    bino "I guess that's the point…"

    show bino eyesopenangry -emotesweat

    bino "That stuff is called cyanide, I think. Sometimes they use sulfur, but either way, both substances are poisonous."

    show street2sausage at inspect_zoom_out
    show bino eyesclosedneutral emotedarkness

    bino "And so they count on us to not notice these in the food..."

    show xoai eyesclosedtears mouthopenwobble emanatadown

    xoai "Would someone really go this far to poison a rat?"

    show bino eyessurprisedannoyed emotesweat -emotedarkness

    bino "..."

    show bino eyesclosedsad

    bino "They want to poison more than rats, sometimes…"

    show xoai eyesopensad mouthclosedwobble -emotetears -emanatadown

    xoai "..."

    show xoai mouthopeno

    xoai "Oh…"

    window hide

    show xoai at exit
    show bino at exit

    show street2sausage at inspection_end
    
    jump street2search

label street2clear:

    show xoai eyesclosedsad mouth3 emanatasweat -browsneutral -emotesweat at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance

    pause 0.3

    window show

    xoai "Ahh, I feel bad… I ate all of the dog food we found…"

    show bino eyesclosedrelaxed

    bino "Well, take care of yourself first. How else are you gonna run around and find food for everyone?"

    show xoai eyessurprisedangry mouthopenhappier emanatasurprise -emanatasweat

    xoai "I'm young, I have energy!!"

    show xoai -emanatasurprise

    xoai "..."

    show xoai emanatadown eyesclosedneutral mouthopenwobble at down

    xoai "...on second thought… I'm a bit tired."

    show bino eyesclosedneutral emotesweat

    bino "That's what I thought…"

    show bino eyesopensad -emotesweat at up

    bino "One more street, okay? I know you don't like to give up halfway."

    show xoai mouth3 -emanatadown at up

    xoai "...yeah."

    show xoai eyesopensad mouthopeno

    xoai "But honestly… I'm not really tired from walking around…"

    show xoai mouthopenwobble

    xoai "I'm just… kinda tired that we have to keep looking out for these poisons."

    show xoai eyesclosedsad emotesweat

    xoai "...It's like we can't trust anyone out here."

    show xoai mouthcloseddot

    xoai "Just one mistake, and…"

    show bino eyesclosedsad

    bino "..."

    show xoai eyesopensad

    xoai "..."

    show xoai emotetears

    xoai "I just don't want what happened to you to happen to anyone again, Bino…"

    show xoai eyesclosedsad mouthclosedwobble

    xoai "It's… hard to believe that people really want to poison dogs…"

    show xoai eyesclosedexcited mouthopenwobble

    xoai "I guess I am just naive after all…"

    show bino eyesopensad

    bino "...well, I guess now I don't have to break the news to you as to why I'm a ghost."

    show bino eyesopenneutral

    bino "But, it's not every human, Xoai. Just be on the lookout, is all."

    show xoai eyessurprisedsad mouthclosedwobble

    xoai "I know, but still…"

    show xoai eyesclosedsad

    xoai "I'm… scared."

    show bino eyesclosedrelaxed

    bino "..."

    bino "I get you."

    show bino eyesclosedsad emotesweat

    bino "I guess it's easy for me to say… because I'm already dead."

    show bino eyessurprisedannoyed

    bino "I can't exactly die twice, so…"

    show bino eyesclosedrelaxed -emotesweat at up

    bino "...but, for you… that fear of dying just from eating one bad thing…"

    show xoai eyesopenaverted mouthopeno -eyesclosedtears

    xoai "...yeah. You get it."

    bino "..."

    show bino eyesclosedsad at bounce

    bino "I'm here with you."

    show bino eyessurprisedannoyed emoteblush

    bino "Always and forever. Remember that."

    show xoai eyesclosedsad mouthclosedwobble

    xoai "..."

    show bino eyesclosedangry emanatasurprise

    bino "One more street, okay?"

    xoai "..."

    show xoai eyesclosedsad mouthopeno

    xoai "Okay."

    window hide

    show xoai at exit
    show bino at exit

    pause 0.3

    jump street3

