label street3:

    # initialise ba discovered to false
    $ ba7found = ba8found = ba9found = False

    jump street3search

label street3search:
    
    $ street3allfound = ba7found * ba8found * ba9found

    if street3allfound == True:
        pause 0.3
        scene street3
        with Fade(0.5, 1, 0.5)
        jump street3clear
    else:
        pause 0.3
        scene street3
        with Fade(0.5, 1, 0)
        call screen street3

screen street3:

    fixed:

        imagebutton:
            xpos 0
            ypos 0
            focus_mask True
            idle "ba/street3coolant.png"
            hover "ba/street3coolant_hover.png"
            sensitive ba7found == False
            action [SetVariable("ba7found", True), Jump("ba7")]
            if ba7found:
                at grey
            
        imagebutton:
            xpos 1700
            ypos 900
            focus_mask True
            idle "ba/street3ratpoison.png"
            hover "ba/street3ratpoison_hover.png"
            at ba50
            sensitive ba8found == False
            action [SetVariable("ba8found", True), Jump("ba8")]
            if ba8found:
                at grey, ba50
            
        imagebutton:
            xpos 1200
            ypos 600
            focus_mask True
            idle "ba/street3meat.png"
            hover "ba/street3meat_hover.png"
            at ba50
            sensitive ba9found == False
            action [SetVariable("ba9found", True), Jump("ba9")]
            if ba9found:
                at grey, ba50

label ba7:

    show xoai eyesdizzy mouthclosedwobble -emoteblush -emanatasurprise at right, entrance
    show bino eyesopenneutral at left, entrance
    pause 0.2

    window show

    xoai "A weird-looking puddle… and it smells sweet?"

    show xoai eyesclosedangry

    xoai "This isn't water… it's… weird looking, really."

    show bino emotesweatprofusely eyesclosedangry -emanataquestion

    bino "Stay back, that's straight up nuclear stuff."

    show bino eyessurprisedannoyed

    bino "Or, well, more specifically, motorbike antifreeze."

    show xoai eyesopenangry mouthopeno

    xoai "Weird. Why is it here?"

    show bino eyesclosedneutral -emotesweatprofusely

    bino "Usually, those repair shops that you see around have a dedicated tank of these to pour into bike engines and stuff."

    show bino emotesweat

    bino "But I guess someone's been a bit lazy and dumped it out onto the street instead…"

    show xoai eyesclosedneutral emanataangry mouthclosedwobble

    xoai "That's annoying…"

    show bino eyessurprisedannoyed

    bino "Yeah. Avoid it at all costs."

    window hide

    show xoai at exit
    show bino at exit

    jump street3search

label ba8:

    show street3ratpoison at center, inspection_start
    pause 0.3

    show xoai eyesclosedangry mouthopenhappy at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance
    pause 0.2

    window show

    xoai "Hah! I know this trick!"

    show xoai mouthtongue eyessurprisedannoyed emotedarkness emanataangry

    xoai "Meat with weird pellets in them! You can't fool me twice!"

    show bino eyesclosedhappy

    bino "Nice job spotting that one, Xoài!"

    show bino eyesclosedrelaxed

    bino "Soon, you won't even need my guidance."

    show xoai emoteblush mouthopenhappier eyesopenneutral -emanataangry

    xoai "Hell yeah, I've made something of myself!"

    show xoai eyesclosedneutral mouth3

    xoai "But uh, it's nice having you around to watch too, you know. I don't always have to be learning something from you…"

    show bino eyesclosedsad

    bino "..."

    show bino emoteblush

    bino "...maybe."

    window hide

    show xoai at exit
    show bino at exit

    show street3ratpoison at inspection_end

    jump street3search

label ba9:

    show street3meat at center, inspection_start
    pause 0.3
    
    show xoai eyesopenneutral mouthopeno -emanatasurprise at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance
    pause 0.2

    window show

    xoai "This is…"

    show xoai mouthclosedwobble emanataquestion eyesdizzy

    xoai "Meat? With rubber bands around it?"

    show xoai eyesdotblack -emanataquestion -emotesweat

    xoai "I don't see any weird pellets, but…"

    xoai "If the others were anything to go off of, then…"

    show xoai eyesclosedsad

    xoai "Rubber bands…"

    show bino eyesclosedneutral

    bino "...are a no-go."

    show xoai mouthopenhappy eyesdotblack

    xoai "Yeah! Something like that!"

    show bino eyessurprisedannoyed emotesweat

    bino "I mean, think about it? Who the hell likes eating rubber bands?!"

    show xoai eyesopenaverted mouthcloseddot emanatadown at down

    xoai "Yeah. Gross."

    window hide

    show xoai at exit
    show bino at exit

    show street3meat at inspection_end
    
    jump street3search

label street3clear:

    show xoai eyesclosedsad mouth3 emanatasweat -browsneutral -emotesweat at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance

    pause 0.3

    window show

    xoai "..."

    show xoai emotesweatprofusely mouthopenwobble emanatadown -emanatasweat

    xoai "We didn't find much after all…"

    show bino eyesclosedrelaxed

    bino "Don't sweat it, Xoai. Let's just head back now."

    show xoai eyesclosedtears mouth3 emanatadown -emotesweatprofusely

    xoai "I was foolish to think it would be fun to go further out…"

    show xoai mouthopeno

    xoai "And find treasure or something…"

    show xoai mouthopenhappier emotetears eyesopensad

    xoai "Like a big stash of meat for all of us!!!"

    show xoai mouthopenwobble

    xoai "But no… it just had to be dog poison, all of it…"

    show bino eyesclosedsad

    bino "..."

    bino "Don't you think you got something out of this, though?"

    show xoai mouthclosedwobble -emanatadown

    xoai "...like what?"

    show xoai eyesopenneutral

    xoai "All I've learnt is that this world is… cruel sometimes…"

    show xoai eyesclosedsad at bounce, down

    xoai "*sniff*" 

    show bino eyesclosedrelaxed

    bino "...now now, I know it's hard…"

    bino "...but you've learnt how to spot these poisons, you know? You got something out of it."

    show bino eyesopensad

    bino "Think about how many lives you could save with this knowledge, Xoai. The whole pack is super safe now, thanks to your wisdom!"

    show xoai eyesclosedneutral

    xoai "...yeah, I guess."

    show xoai eyesclosedtears emanatadown -emotetears

    xoai "I wish it didn't have to come at the cost of you though…"

    show bino eyesclosedrelaxed

    bino "...I understand."

    show xoai eyesclosedsad emotetears -emanatadown

    xoai "..."

    show xoai mouthopenwobble

    xoai "You're not actually here, are you Bino?"

    show xoai mouthclosedwobble

    xoai "I'm just like, making stuff up."

    show xoai eyesclosedneutral

    xoai "Ghosts don't exist, and even if they did…"

    show xoai emotesweat

    xoai "...they certainly wouldn't look like jello skeletons… right?"

    show bino eyesclosedsad -emoteblush

    bino "..."

    show bino emotesweat

    bino "Does it matter?"

    show xoai emotetears eyesclosedsad -emotesweat

    xoai "..."

    show bino eyesclosedrelaxed -emotesweat

    bino "...Xoai. Even if I'm just in your visions or whatever… You've still learnt something concrete from me. Like, real."

    show bino eyesopensad

    bino "That knowledge, you've gotta pass it on, you know? From the ghost world to the real world."

    show xoai emotetears

    xoai "...yeah."

    show xoai eyesclosedangry

    xoai "I haven't been a good chef today but… I can be a good teacher at least."

    show xoai eyesclosedtears mouthopenwobble -emotetears

    xoai "I just wish you were still here with us."

    show bino eyesclosedrelaxed

    bino "..."

    bino "I guess there's no easy way around that feeling."

    show bino eyesopensad

    bino "I'm sorry, Xoai."

    show xoai mouthclosedwobble

    xoai "..."

    show xoai mouthopenwobble eyesopensad emotetears

    xoai "...It's okay. It's not your fault."

    show xoai eyesopenangry mouthclosedwobble

    xoai "I'm still sad… but… there's still one thing I need to do."

    show bino emanataquestion eyesopenneutral

    bino "...and what is it?"

    show xoai eyesclosedrelaxed mouthcloseddot

    xoai "...well…"

    show xoai eyesclosedsad mouthsmileteeth

    xoai "Let's go home first."

    show bino eyesclosedrelaxed -emanataquestion

    bino "...I believe in you."

    window hide

    show xoai at exit
    show bino at exit

    pause 0.3

    jump epilogue

