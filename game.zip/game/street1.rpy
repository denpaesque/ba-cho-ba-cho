label street1:

    scene street1
    with Fade(0.5, 1, 0.5)

    show xoai eyesopenangry mouthclosedwobble at right, entrance

    pause 0.3

    window show

    xoai "..."

    show xoai mouthopenwobble emanatasweat eyesclosedsad -browssad at down

    xoai "Oof, I travelled too far out…"

    show xoai eyesopenangry -emanatasweat -browssad at up

    xoai "Well whatever..."

    show xoai mouthcloseddot

    xoai "The market people are extra busy today, so I shouldn't be bothering them as much anyway…"

    show xoai

    xoai "Now, let's see where we can find food…"

    xoai "*scavenging*"

    show xoai emanataquestion mouthopeno at bounce

    xoai "Eh? What's this?"

    show prologueratpoison at center, inspection_start
    show xoai -emanataquestion at right

    xoai "This stuff is candy, right?"

    show xoai eyesopenaverted mouthopenhappy

    xoai "I see humans eating these all the time…"

    show xoai

    xoai "..."

    show xoai eyesclosedhappy emanatasurprise mouthopenhappier -browssad at up

    xoai "Well what do you know! It's our lucky day to try a new cuisine."

    show xoai eyesclosedsad mouthtongue -emanatasurprise

    xoai "I should probably taste test it first though.."

    show xoai mouthopendrool eyesclosedsad -browsneutral

    xoai "Here goes nothin-"

    show xoai eyessurprisedneutral -browssad

    unknown "DON'T EAT IT!!!"

    show xoai eyessurprisedneutral emanatasurprise mouthopenhappy emotesweat at bounce

    xoai "Ehh!?????"

    show xoai
    show bino eyessurprisedangry at left, entrance

    unknownfocus "Xoài!!! It's me!!! You remember me, right??"

    show xoai eyesopensad emotesweat mouthopenwobble -emanatasurprise
    show bino

    xoai "Ehh?? No?? What?? Wait.."

    show xoai eyesopenneutral -emotesweat
    show bino

    xoai "..."

    show xoai mouthopeno eyessurprisedneutral emanatasurprise at bounce
    show bino

    xoai "Bino? Is that you??"

    show xoai
    show bino emotesweat eyesclosedsad

    bino "Yep! Uh, don't mind the not-so-corporeal form…"

    show xoai eyesclosedhappy mouthopenhappy -emanatasurprise -browssad
    show bino

    xoai "No worries… I won't question it…"

    show xoai -emotedarkness -browsneutral
    show bino

    xoai "..."

    show xoai emotedarkness emanataangry eyesclosedangry -browsangry
    show bino

    xoai "Hey, if you wanted the candy for yourself, you could have just told me!!"
    
    show xoai
    show bino eyessurprisedannoyed emanatadown -emotesweat


    bino "It's not that!! It's poison, Xoài.."
    
    show xoai eyesopensad emanataquestion emotesweat -emanataangry -emotedarkness -browsangry
    show bino


    xoai "Ehh? Poison? Why here??"
    
    show xoai
    show bino eyesclosedsad emotesweat -emanatadown


    bino "It's for the rats. People kind of want to get rid of them. Rodenticides and whatnot."
    
    show prologueratpoison at inspection_end
    show xoai mouth3 eyesclosedhappy -emanatasurprise -emanataquestion -emotesweat -browssad
    show bino


    xoai "Ah ok, these aren't for us then!"
    
    show xoai mouthopenwobble emotesweat -browsneutral
    show bino


    xoai "Jeez.."
    
    show xoai mouthopenhappy -browssad at bounce
    show bino


    xoai "You scared me for a moment there, Bino! I thought there were people actually out to get us!!"
    
    show xoai
    show bino eyessurprisedneutral emanatasweat emotesweat -emotesweatprofusely


    bino "..."
    
    show xoai
    show bino eyesclosedsad


    bino "Well, about that…"
    
    show xoai
    show bino


    bino "..."
    
    show xoai
    show bino eyesclosedhappy -emanatasweat -emotesweat at bounce


    bino "...nevermind. You're scavenging, right? I can just be on the lookout for you."
    
    show xoai mouth3 emoteblush eyesopensad -emotesweat -browssad
    show bino


    xoai "Aww, thanks so much Bino!! You're the best…"
    
    show xoai eyesclosedhappy mouthopenhappy -browssad
    show bino


    xoai "I've missed you all this time, you know!! It just hasn't been the same.."
    
    show xoai mouth3 eyesclosedsad
    show bino


    xoai "...so it's nice that you're here now, like the old days…"
    
    show xoai
    show bino eyessurprisedannoyed emotesweat -emotesweatprofusely


    bino "..."
    
    show xoai
    show bino eyesclosedneutral


    bino "Bit too sappy."
    
    show xoai eyesclosedexcited mouthopenhappier emotesweat
    show bino


    xoai "Teehee, sorry…"
    
    show xoai eyesopenneutral mouthopeno -browssad -emotesweat
    show bino


    xoai "Well, now that we're this far out, we might as well continue searching around here!"
    
    show xoai mouthopenhappier eyesclosedneutral
    show bino


    xoai "I'll just look around for more food, 'kay? I've got the whole pack to feed!"

    show xoai
    show bino eyesopenneutral -emotesweat

    bino "Right there with ya."


    show xoai at exit
    show bino at exit

    window hide 

    # initialise ba discovered to false
    $ ba1found = ba2found = ba3found = False
    jump street1search

label street1search:
    
    $ street1allfound = ba1found * ba2found * ba3found

    if street1allfound == True:
        pause 0.3
        scene street1
        with Fade(0.5, 1, 0.5)
        jump street1clear
    else:

        pause 0.3
        scene street1
        with Fade(0.5, 1, 0)
        call screen street1
    
screen street1:

    fixed:

        imagebutton:
            xpos 1400
            ypos 840
            focus_mask True
            idle "ba/street1meat.png"
            hover "ba/street1meat_hover.png"
            at ba50
            sensitive ba1found == False
            action [SetVariable("ba1found", True), Jump("ba1")]
            if ba1found:
                at grey, ba50

            
        imagebutton:
            xpos 600
            ypos 440
            focus_mask True
            idle "ba/street1lollipop.png"
            hover "ba/street1lollipop_hover.png"
            at ba50
            sensitive ba2found == False
            action [SetVariable("ba2found", True), Jump("ba2")]
            if ba2found:
                at grey, ba50
            
        imagebutton:
            xpos 800
            ypos 940
            focus_mask True
            idle "ba/street1ratpoison.png"
            hover "ba/street1ratpoison_hover.png"
            at ba75
            sensitive ba3found == False
            action [SetVariable("ba3found", True), Jump("ba3")]
            if ba3found:
                at grey, ba75

label ba1:

    show street1meat at center, inspection_start
    pause 0.3

    show xoai emanatasurprise eyessurprisedneutral mouth3 -browsneutral -browssad -emotesweat at right, entrance
    show bino eyesopenneutral at left, entrance

    pause 0.2

    window show
    
    xoai "Hey!! A chunk of beef!!"

    show xoai eyesclosedrelaxed -emanatasurprise

    xoai "It's small, but it'll do. We're missing some actual proteins after all…"

    show bino eyesopenangry

    bino "That's a bad one, Xoài."

    show bino eyesopenneutral

    bino "Look closer. Don't you see anything wrong?"

    show xoai eyesopenaverted mouthopeno emotesweat -browsneutral

    xoai "..."

    show xoai eyesclosedexcited mouthopenwobble emotesweatprofusely emanatadown at down

    xoai "Not really, no."

    show bino eyessurprisedangry
    show street1meatred at center, meat_highlight

    bino "This pouch, right here. It's poison, Xoài!"

    show bino eyesclosedhappy emotedarkness

    bino "The humans think they are smart for sneaking it into meat like this."

    show xoai eyesdizzy emanatasweat mouthopeno -browssad at up
    show street1meatred at meat_highlight_remove

    xoai "Ehh!! Why would they do that?"

    show bino eyesclosedneutral -emotedarkness

    bino "So it attracts animals. Cuz we like meat, y'know."

    show bino eyesopensad

    bino "These pouches are bad business for us."

    show xoai mouthclosedwobble eyesopensad -emotesweatprofusely -emanatasweat

    xoai "Jeez…"

    show xoai mouthcloseddot

    xoai "It's as if they're tailoring these poisons for dogs…"

    show bino eyesclosedsad -emotesweat

    bino "..."

    show bino emotesweat

    bino "..."

    window hide

    show xoai at exit
    show bino at exit

    show street1meat at inspection_end

    jump street1search

label ba2:

    show street1lollipop at center, inspection_start
    pause 0.3

    show xoai eyesopenneutral mouthopeno at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance
    pause 0.2

    window show

    xoai "What the hell is this thing? It smells kinda nice, but it looks suspicious…"

    bino "One of these 'lollipop' baits."

    show bino eyesopenangry

    bino "The 'candy' part is what's meant to be eaten, filled with both meat and poison."

    bino "And the thin 'handle' is for the humans to hold them safely."

    show xoai eyesclosedexcited mouthclosedwobble emotesweat

    xoai "Ouch…"

    show xoai eyesdotwhite

    xoai "So they make it safe for them, but dangerous for animals like us, huh…"

    show bino eyesclosedrelaxed

    bino "Yeah, unfortunately."

    window hide

    show xoai at exit
    show bino at exit

    show street1lollipop at inspection_end

    jump street1search

label ba3:

    show street1ratpoison at center, inspection_start
    pause 0.3

    show xoai emanataangry mouthopenwobble eyesopenangry -emotesweat at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance
    pause 0.2

    window show
    
    xoai "Another one of these evil rat poison candies! The weird pellet shape says it all!"

    show bino eyesopenangry

    bino "Exactly! You're getting the hang of this."

    show xoai eyesclosedrelaxed mouthtongue -emanataangry

    xoai "Don't worry, it's nothing. They stick out like a sore thumb to me now."

    show xoai eyesopenangry mouthopenwobble -browsneutral

    xoai "Still, I should take note of these and tell the gang to avoid them."

    show xoai eyesopensad

    xoai "It only takes one mistake, after all…"

    bino "..."

    show bino eyesopensad

    bino "Yeah, one mistake…"

    window hide

    show xoai at exit
    show bino at exit

    show street1ratpoison at inspection_end
    
    jump street1search

label street1clear:

    show xoai eyesopenneutral mouthclosedwobble -browsneutral emotesweat at right, entrance
    show bino eyesopenneutral -emotesweat at left, entrance

    pause 0.3

    window show
    
    xoai "..."

    show xoai eyesclosedangry

    xoai "Wow, this alleyway has nothing."

    show bino eyesclosedsad

    bino "We better look somewhere else then."

    show bino eyesclosedneutral emoteblush

    bino "You lead the way."

    show xoai eyesclosedexcited mouthopenhappier emanatasurprise emoteblush -emotesweat

    xoai "Okay!! This way!"

    window hide

    show xoai at exit
    show bino at exit

    pause 0.3

    jump street2

