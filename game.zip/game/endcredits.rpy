
label creditsroll:
    
    scene prelogue4
    with Fade(0.5, 3, 0)

    endcredits """{cps=90}\nCredits{w=0.5}{nw}{/cps}
    
    {cps=90}Art, Programming: Izzy (denpaesque){w=0.5}{nw}{/cps}

    {cps=90}\n\nStreet Backgrounds:{w=0.5}{nw}{/cps}

    {cps=90}https://rosietheleo.wordpress.com/2018/09/24/hem-sai-gon/{w=0.2}{nw}{/cps}
    
    {cps=90}https://sloth.vn/chill/kham-pha-con-hem-dai-nhat-sai-gon{w=0.2}{nw}{/cps}
    
    {cps=90}https://www.flickr.com/photos/58797195@N02/5501632775/{w=1}{nw}{/cps}"""
    nvl clear

    endcredits """{cps=90}\nDog Bait Images:{w=0.5}{nw}{/cps}

    {cps=90}https://baovephapluat.vn/van-hoa-xa-hoi/y-te/canh-bao-nguy-co-chet-nguoi-vi-ba-cho-ba-chuot-giong-keo-34730.html{w=0.1}{nw}{/cps}

    {cps=90}https://baolamdong.vn/ba-cho-la-gi-dau-hieu-nhan-biet-va-cach-xu-ly-khi-bi-trung-ba-174532.html{w=0.1}{nw}{/cps}

    {cps=90}https://tuoitre.vn/nguy-hiem-ba-cho-thuoc-diet-chuot-hinh-keo-1238512.htm{w=0.1}{nw}{/cps}

    {cps=90}https://pawsforcompassion.org/keep-your-pet-safe-from-poison-and-theft/{w=0.1}{nw}{/cps}
    
    {cps=90}https://www.m5s.vn/ba-cho-la-gi.html{w=1}{nw}{/cps}

    {clear}

    {cps=90}\n\n\n\nhttps://dantri.com.vn/thoi-su/cong-an-canh-bao-hiem-hoa-chet-nguoi-tu-ba-cho-hinh-keo-mut-20201105121035703.htm{w=0.1}{nw}{/cps}

    {cps=90}https://morepetfoods.com/uk/dog-food/adult-digestion-chicken-oats-all-breeds-dry-dog-food/{w=0.1}{nw}{/cps}

    {cps=90}https://yolo.com.vn/ba-cho-la-gi/{w=0.1}{nw}{/cps}

    {cps=90}https://www.facebook.com/share/p/1FXCcjY8Q7/ {w=1}{nw}{/cps}
    """
    nvl clear

    endcredits """
    {cps=90}\n\nPlugins:{w=0.5}{nw}{/cps}

    {cps=90}Auto Highlight: SoDaRa{w=0.5}{nw}{/cps}

    {cps=90}Layered Image Visual Editor in Ren'Py: Cute Shadow{w=2.0}{nw}{/cps}

    \n\n\n\nThank you for playing!{w}
    
    """