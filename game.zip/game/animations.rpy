transform bounce:
    ease .06 yoffset -24
    ease .03 yoffset 0

transform down:
    ease 0.6 yoffset 24
    
transform up:
    ease 0.6 yoffset 0

#xoai and bino entrance and exit

transform entrance:
    yoffset 30 alpha 0.5

    ease 0.5*(not renpy.is_skipping()) yoffset 0 alpha 1

transform exit:
    ease 0.5*(not renpy.is_skipping()) yoffset 30 alpha 0

# inspecting the ba
transform inspection_start:
    zoom 2 yoffset 60 alpha 0.2

    ease 0.3 yoffset 0 alpha 1

transform inspection_end:

    ease 0.2 yoffset 60 alpha 0

transform inspect_zoom_in:
    zoom 2

    ease 0.3 zoom 3

transform inspect_zoom_out:
    zoom 3

    ease 0.3 zoom 2

transform meat_highlight:
    zoom 2 alpha 0

    ease 0.3 alpha 1

transform meat_highlight_remove:
    ease 0.3 alpha 0
    
# resizing ba on streets
transform ba75:
    zoom 0.75

transform ba50:
    zoom 0.5

#greyed out
transform grey:
    matrixcolor SaturationMatrix(0.2)