#remap keys
init:

    $ config.keymap = dict(
    
    # # UNCOMMENT FOR DEBUG
    
    # # reload_game = [ 'alt_K_r', 'shift_K_r' ],
    # inspector = [ 'alt_noshift_K_i', 'shift_K_i' ],
    # full_inspector = [ 'alt_shift_K_i' ],
    # developer = [ 'alt_K_d', 'shift_K_d',],
    # rollback = [ 'anyrepeat_K_PAGEUP', 'anyrepeat_KP_PAGEUP', 'K_AC_BACK', 'mousedown_3', 'K_TAB' ],
    # quit = [ ],
    # iconify = [ ],
    # help = [ ],
    # choose_renderer = [ ],
    # progress_screen = [ ],
    # bubble_editor = [ ],
    # # Debug console.
    # console = [ 'shift_K_o', 'alt_shift_K_o' ],
    # console_exit = [ 'K_ESCAPE', 'K_MENU', 'K_PAUSE', 'mouseup_3' ],
    # console_older = [ 'anyrepeat_K_UP', 'anyrepeat_KP_UP' ],
    # console_newer = [ 'anyrepeat_K_DOWN', 'anyrepeat_KP_DOWN' ],
    # # Director
    # director = [ 'K_d' ],
    # # Profile commands.
    # performance = [ 'K_F3' ],
    # image_load_log = [ 'K_F4' ],
    # profile_once = [ 'K_F8' ],
    # memory_profile = [ 'K_F7' ],
    # # These keys control skipping.
    # skip = [ 'anymod_K_LCTRL', 'anymod_K_RCTRL' ],
    # stop_skipping = [ ],
    # toggle_skip = [ ],

    # UNCOMMENT FOR DEPLOYING
    
    reload_game = [ ],
    inspector = [ ],
    full_inspector = [],
    developer = [ ],
    rollback = [ ],
    quit = [ ],
    iconify = [ ],
    help = [ ],
    choose_renderer = [ ],
    progress_screen = [ ],
    bubble_editor = [ ],
    # Debug console.
    console = [ ],
    console_exit = [ ],
    console_older = [ ],
    console_newer = [ ],
    # Director
    director = [ ],
    # Profile commands.
    performance = [ ],
    image_load_log = [ ],
    profile_once = [ ],
    memory_profile = [ ],
    # These keys control skipping.
    skip = [ ],
    stop_skipping = [ ],
    toggle_skip = [ ],
    fast_skip = [ ],

    # Bindings present almost everywhere, unless explicitly
    # disabled.
    screenshot = [ ],
    toggle_afm = [ ],
    toggle_fullscreen = [ 'alt_K_RETURN', 'alt_K_KP_ENTER', 'K_F11', 'noshift_K_f' ],
    game_menu = [ ],
    hide_windows = [ ],
    launch_editor = [ ],
    dump_styles = [ ],

    # Accessibility.
    accessibility = [ ],
    self_voicing = [ ],
    clipboard_voicing = [ ],
    debug_voicing = [ ],
    extra_voicing = [ ],

    # Say.
    rollforward = [ 'anyrepeat_K_PAGEDOWN', 'anyrepeat_KP_PAGEDOWN', 'mousedown_5',],
    dismiss = [ 'K_RETURN', 'K_SPACE', 'K_KP_ENTER', 'K_SELECT', 'mouseup_1' ],
    dismiss_unfocused = [ ],

    # Pause.
    dismiss_hard_pause = [ ],

    # Focus.
    focus_left = [ 'anyrepeat_K_LEFT', 'anyrepeat_KP_LEFT' ],
    focus_right = [ 'anyrepeat_K_RIGHT', 'anyrepeat_KP_RIGHT' ],
    focus_up = [ 'anyrepeat_K_UP', 'anyrepeat_KP_UP' ],
    focus_down = [ 'anyrepeat_K_DOWN', 'anyrepeat_KP_DOWN' ],

    # Button.
    button_ignore = [ 'mousedown_1' ],
    button_select = [ 'K_RETURN', 'K_KP_ENTER', 'K_SELECT', 'mouseup_1',],
    button_alternate = [ 'mouseup_3' ],
    button_alternate_ignore = [ 'mousedown_3' ],

    # Input.
    input_backspace = [ 'anyrepeat_K_BACKSPACE' ],
    input_enter = [ 'K_RETURN', 'K_KP_ENTER' ],
    input_next_line = [ 'shift_K_RETURN', 'shift_K_KP_ENTER' ],
    input_left = [ 'anyrepeat_K_LEFT', 'anyrepeat_KP_LEFT' ],
    input_right = [ 'anyrepeat_K_RIGHT', 'anyrepeat_KP_RIGHT' ],
    input_up = [ 'anyrepeat_K_UP', 'anyrepeat_KP_UP' ],
    input_down = [ 'anyrepeat_K_DOWN', 'anyrepeat_KP_DOWN' ],
    input_delete = [ 'anyrepeat_K_DELETE', 'anyrepeat_KP_DELETE' ],
    input_home = [ 'K_HOME', 'KP_HOME', 'meta_K_LEFT' ],
    input_end = [ 'K_END', 'KP_END', 'meta_K_RIGHT' ],
    input_copy = [ 'ctrl_noshift_K_INSERT', 'ctrl_noshift_K_c', 'meta_noshift_K_c' ],
    input_paste = [ 'shift_K_INSERT', 'ctrl_noshift_K_v', 'meta_noshift_K_v' ],
    input_jump_word_left = [ 'osctrl_K_LEFT', 'osctrl_KP_LEFT' ],
    input_jump_word_right = [ 'osctrl_K_RIGHT', 'osctrl_KP_RIGHT' ],
    input_delete_word = [ 'osctrl_K_BACKSPACE' ],
    input_delete_full = [ 'meta_K_BACKSPACE' ],

    # Viewport.
    viewport_leftarrow = [ 'anyrepeat_K_LEFT', 'anyrepeat_KP_LEFT' ],
    viewport_rightarrow = [ 'anyrepeat_K_RIGHT', 'anyrepeat_KP_RIGHT' ],
    viewport_uparrow = [ 'anyrepeat_K_UP', 'anyrepeat_KP_UP' ],
    viewport_downarrow = [ 'anyrepeat_K_DOWN', 'anyrepeat_KP_DOWN' ],
    viewport_wheelup = [ 'mousedown_4' ],
    viewport_wheeldown = [ 'mousedown_5' ],
    viewport_drag_start = [ 'mousedown_1' ],
    viewport_drag_end = [ 'mouseup_1' ],
    viewport_pageup = [ 'anyrepeat_K_PAGEUP', 'anyrepeat_KP_PAGEUP'],
    viewport_pagedown = [ 'anyrepeat_K_PAGEDOWN', 'anyrepeat_KP_PAGEDOWN' ],

    # Bar.
    bar_activate = [ 'mousedown_1', 'K_RETURN', 'K_KP_ENTER', 'K_SELECT' ],
    bar_deactivate = [ 'mouseup_1', 'K_RETURN', 'K_KP_ENTER', 'K_SELECT' ],
    bar_left = [ 'anyrepeat_K_LEFT', 'anyrepeat_KP_LEFT' ],
    bar_right = [ 'anyrepeat_K_RIGHT', 'anyrepeat_KP_RIGHT' ],
    bar_up = [ 'anyrepeat_K_UP', 'anyrepeat_KP_UP' ],
    bar_down = [ 'anyrepeat_K_DOWN', 'anyrepeat_KP_DOWN' ],

    # Delete a save.
    save_delete = [ 'K_DELETE', 'KP_DELETE' ],

    # Save/load screen pagination.
    save_page_prev = ['mousedown_4'],
    save_page_next = ['mousedown_5'],

    # Draggable.
    drag_activate = [ 'mousedown_1' ],
    drag_deactivate = [ 'mouseup_1' ],

    # Ignored (kept for backwards compatibility).
    toggle_music = [ ],
    viewport_up = [ ],
    viewport_down = [ ],

)