﻿label main_menu:
    return

# The game starts here.

label start:

    window hide

    menu:
        story "Select your language."

        "English":
            $ renpy.change_language(None)
        
        "Tiếng Việt":
            $ renpy.change_language("viet")

    scene prelogue1
    with Fade(0.0, 2, 0.0)

    story "201X\nSAIGON, BA CHIEU MARKET"

    story "Ever since Bino left us, the stray dogs around Ba Chieu have been scared of searching for food..."

    scene prelogue2

    story "It was rumoured that one day... he went out scouring the streets for leftovers..."

    scene prelogue3

    story "And before we knew it..."

    scene prelogue4

    story "..."

    story "No one knows what happened to him, and no one has dared to scavenge for long since..."

    scene prelogue5

    story "..."

    scene prelogue6

    story "*stomach growl*"

    scene prelogue7

    story "\"I'm so hungry...\""

    scene prelogue8

    story "\"...\""

    scene prelogue9

    story "\"But this has to change now!!\""

    scene prelogue10

    story "\"This isn't what Bino would have wanted..\""

    scene prelogue11

    story "\"And besides, we're gonna get really tired of eating small meals every day...\""

    scene prelogue12

    story "\"I'm the chef of this street, for god's sake! I have to be brave and bring home food for everyone!!\""

    scene prelogue13

    story "*deep breath*"

    scene prelogue14

    story "\"Let's do this!!\""

    jump street1
