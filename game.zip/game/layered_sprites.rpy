layeredimage xoai:

    at sprite_highlight('xoai')

    always "xoai_base"

    group eyes:

        attribute eyesopenneutral default
        attribute eyesopenangry
        attribute eyesopensad
        attribute eyesopenaverted

        attribute eyesclosedneutral
        attribute eyesclosedangry
        attribute eyesclosedsad
        attribute eyesclosedtears
        attribute eyesclosedhappy
        attribute eyesclosedrelaxed
        attribute eyesclosedexcited

        attribute eyesstars
        attribute eyesdizzy

        attribute eyessurprisedneutral
        attribute eyessurprisedangry
        attribute eyessurprisedsad
        attribute eyessurprisedannoyed

        attribute eyesdotblack
        attribute eyesdotwhite

    group brows:

        attribute browsneutral
        attribute browsangry
        attribute browssad

    group mouth:

        attribute mouth3 default

        attribute mouthopeno
        attribute mouthopenwobble
        attribute mouthopendrool
        attribute mouthopenhappy
        attribute mouthopenhappier

        attribute mouthclosedwobble
        attribute mouthcloseddot

        attribute mouthsmileteeth
        attribute mouthsmilenerd
        attribute mouthtongue

    group emotes:

        attribute emoteblush
        attribute emotedarkness
        attribute emotesweat
        attribute emotesweatprofusely
        attribute emotetears
        attribute emotetail

    group emanata:

        attribute emanataquestion
        attribute emanatasurprise
        attribute emanatasweat
        attribute emanatadown
        attribute emanataangry

layeredimage bino:

    at sprite_highlight('bino')

    always "bino_base"

    group eyes:

        attribute eyesopenneutral default
        attribute eyesopenangry
        attribute eyesopensad

        attribute eyesclosedneutral
        attribute eyesclosedangry
        attribute eyesclosedsad
        attribute eyesclosedhappy
        attribute eyesclosedrelaxed
        attribute eyesclosedexcited

        attribute eyessurprisedneutral
        attribute eyessurprisedangry
        attribute eyessurprisedsad
        attribute eyessurprisedannoyed

    group emotes:

        attribute emoteblush
        attribute emotedarkness
        attribute emotesweat
        attribute emotesweatprofusely
        attribute emotetail

    group emanata:

        attribute emanataquestion
        attribute emanatasurprise
        attribute emanatasweat
        attribute emanatadown
        attribute emanataangry


